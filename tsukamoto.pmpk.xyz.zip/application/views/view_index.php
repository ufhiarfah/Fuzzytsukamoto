<div class="containerxx">
<h1><?=$judul?></h1>
<hr>

    <div class="col-md-12 gedf-main">
        <div class="card border-left-primary">
            <div class="card-header"><?= $judul_mini; ?></div>
            <div class="card-body">
            </div>
        </div>
    </div>

</div>
