<br />
<strong><?= $title ?></strong><br />
<hr />
<?= $this->session->flashdata('message'); ?>

<!-- Button trigger modal -->
<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#tambahAturan">
    <i class="fas fa-plus"></i> Tambah Aturan
</button>

<!-- Modal -->
<div class="modal fade" id="tambahAturan" tabindex="-1" role="dialog" aria-labelledby="tambahAturanLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="tambahAturanLabel">Tambah Aturan</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">

                <form method="POST" action="<?= site_url('admin/aturan/save') ?>" id="formTambahAturan">
                    <div class="card-body">
                        <div class="row">
                            <?php foreach ($tabelvariabel as $variabel) : ?>
                                <div class="col-md-12">
                                    <div class="form-group row">
                                        <div class="col-md-12">
                                            <label for="id_variabel"><?= $variabel->status_variabel == "input" ? "IF" : "THEN" ?> <?= $variabel->nama_variabel ?></label>
                                            <input type="hidden" name="id_variabel[]" id="id_variabel[]" value="<?= $variabel->id_variabel ?>">
                                            <select class="form-control" name="id_himpunan[]" id="id_himpunan[]">
                                                <option value="">Pilih Himpunan <?= $variabel->nama_variabel ?></option>
                                                <?php foreach ($tabelhimpunan as $himpunan) : if ($variabel->id_variabel == $himpunan->id_variabel) { ?>
                                                        <option value="<?= $himpunan->id_himpunan ?>"><?= $himpunan->nama_himpunan ?></option>
                                                        <!-- <option value="<?= $himpunan->id_himpunan ?>"><?= $himpunan->nama_himpunan ?>, Batas Bawah: <?= $himpunan->batas_bawah ?>, Batas Atas: <?= $himpunan->batas_atas ?></option> -->
                                                <?php }
                                                endforeach ?>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach ?>
                        </div>
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-primary" form="formTambahAturan"><i class="fas fa-save"></i> Save</button>
            </div>
        </div>
    </div>
</div>

<hr>
<div class="table-responsive">
    <table class="table table-sm table-bordered table-striped nw" id="dataTable" width="100%" cellspacing="0">
        <thead>
            <tr>
                <th>No</th>
                <th>Kode Uniq</th>
                <?php foreach ($tabelvariabel as $item) : ?>
                    <th>
                        <?= $item->status_variabel == "input" ? "IF" : "THEN" ?><br>
                        <small><?= $item->nama_variabel ?></small>
                    </th>
                <?php endforeach ?>
                <th></th>
            </tr>
        </thead>
        <tbody>
            <?php $no = 1;
            foreach ($tabelaturangroupby as $rowaturan) {
                $nomor = $rowaturan->nomor;
            ?>
                <tr title="<?= $rowaturan->id_aturan; ?>">
                    <td><?= $no++; ?></td>
                    <td><?= $nomor; ?> </td>
                    <?php foreach ($tabelaturan as $aturan) : if ($aturan->nomor == $nomor) { ?>
                            <td>
                                <?php
                                foreach ($tabelhimpunan as $rowhimpunan) {
                                    if ($aturan->id_variabel == $rowhimpunan->id_variabel) {
                                        if ($rowhimpunan->id_himpunan == $aturan->id_himpunan) {
                                            echo $rowhimpunan->nama_himpunan;
                                        }
                                    }
                                }
                                ?>
                            </td>
                    <?php }
                    endforeach ?>
                    <td>
                        <a onclick="return confirm('Hapus data?');" class="btn btn-danger" href="<?php echo site_url('admin/aturan/delete/' . $nomor); ?>"><i class="fas fa-trash"></i></a>
                    </td>
                </tr>
            <?php } ?>
        </tbody>
    </table>
</div>

<script type="text/javascript">
    $(document).ready(function() {
        $('#dataTable').DataTable({
            fixedColumns: {
                left: 0,
                right: 0
            },
            dom: 'Bfrtip',
            paging: true,
            searching: true,
            bInfo: true,
            buttons: [
                'copy',
                {
                    extend: 'excel',
                    title: '<?= $title ?> | <?= $lembaga ?>'
                },
                {
                    extend: 'pdf',
                    title: '<?= $title ?> | <?= $lembaga ?>'
                },
                {
                    extend: 'print',
                    title: '<?= $title ?> | <?= $lembaga ?>'
                }, 'colvis'
            ]
        });
    });
</script>