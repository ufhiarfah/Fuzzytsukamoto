<br />
<strong><?= $title ?></strong><br />
<hr />

<?php
$ci = &get_instance();
if (!isset($_POST['button'])) { ?>
    <form name="form1" method="post" action="" enctype="multipart/form-data"><br>
        <table class="table table-sm table-bordered table-striped">
            <tr>

                <th colspan="3">Input Data Proposal</th>
            </tr>
            <tr>
                <td>NIK</td>
                <td colspan=2>
                    <input class="form-control" id="nik" name="nik" type="number" required>
                </td>
            </tr>
            <tr>
                <td>Nama Lengkap Sesuai KTP</td>
                <td colspan=2>
                    <input class="form-control" id="nama_lengkap" name="nama_lengkap" type="text" required>
                </td>
            </tr>
            <tr>
                <td>Jenis Kelamin</td>
                <td colspan=2>
                    <SELECT class="form-control" id="jenis_kelamin" name="jenis_kelamin" required>
                        <option value="">Pilih Jenis Kelamin</option>
                        <option value="Laki-laki">Laki-laki</option>
                        <option value="Perempuan">Perempuan</option>
                    </SELECT>
                </td>
            </tr>
            <tr>
                <td>Tempat & Tanggal Lahir</td>
                <td>
                    <input class="form-control" id="tempat_lahir" name="tempat_lahir" type="text" required>
                </td>
                <td>
                    <input class="form-control" id="tgl_lahir" name="tgl_lahir" type="date" required onchange="checkUmur();">
                    <script>
                        function checkUmur() {
                            const dob = new Date(document.getElementById("tgl_lahir").value);
                            // dob = document.getElementById("dob").value;
                            // dob = new Date(dob);
                            const today = new Date();
                            const age = Math.floor((today - dob) / (365.25 * 24 * 60 * 60 * 1000));

                            if (age <= 17) {
                                // console.log(`${age}, You must be 17 or older to fill out this form\n`);
                                alert(`Umur proposal yang di daftar saat ini adalah ${age} tahun, Proposal yang di daftar harus berumur minimal 17 tahun per hari ini\n`);
                                document.getElementById("tgl_lahir").value = "";
                                // } else if (age >= 80) {
                                //     console.log(`${age}, You must be 80 or younger to fill out this form\n`);
                            } else {
                                console.log(`${age}, You may fill out this form\n`);
                            }
                        }
                    </script>
                </td>
            </tr>
            <tr>
                <td>Alamat</td>
                <td colspan=2>
                    <input class="form-control" id="alamat" name="alamat" type="text" required>
                </td>
            </tr>
            <tr>
                <td>Nama Usaha</td>
                <td colspan=2>
                    <input class="form-control" id="nama_usaha" name="nama_usaha" type="text" required>
                </td>
            </tr>
            <tr>
                <td>Deskripsi Usaha</td>
                <td colspan=2>
                    <textarea class="form-control" id="deskripsi_usaha" name="deskripsi_usaha" required placeholder="Jelaskan tentang usaha secara singkat..."></textarea>
                </td>
            </tr>
            <tr>
                <td>Upload Proposal Usaha</td>
                <td colspan=2>
                    <input class="form-control" id="proposal_usaha" name="proposal_usaha" type="file" required>
                </td>
            </tr>
            <?php
            $q = "SELECT * FROM variabel WHERE status_variabel='input' ORDER BY id_variabel";
            $result = $ci->db->query($q)->result();
            foreach ($result as $r) {
                $id_variabel = $r->id_variabel;
            ?>
                <tr>
                    <td><?= $r->nama_variabel; ?> (<?= $r->satuan_variabel; ?>)</td>
                    <td>
                        <input class="form-control" id="variabel<?= $r->id_variabel; ?>" name="variabel<?= $r->id_variabel; ?>" type="number" value="0" required>
                    </td>
                    <td>
                        <?php
                        $q21 = "SELECT * FROM himpunan WHERE id_variabel='$id_variabel' ORDER BY FIELD(status_himpunan, 'bahu kiri', 'bahu kanan') ASC";
                        $q22 = "SELECT * FROM himpunan WHERE id_variabel='$id_variabel' ORDER BY FIELD(status_himpunan, 'bahu kiri', 'bahu kanan') DESC";
                        //echo "SELECT * FROM himpunan WHERE id_variabel='$r->id_variabel' ORDER BY FIELD(status_himpunan, 'bahu kiri', 'bahu kanan')";
                        $r21 = $ci->db->query($q21)->row();
                        $r22 = $ci->db->query($q22)->row();
                        ?>
                        <table class="table">
                            <tr>
                                <td>Keterangan: <br>
                                    <?= ($r->keterangan1 == "") ? "-" : $r->keterangan1; ?>
                                </td>
                                <!-- <td>
                                    <?= $r21->nama_himpunan; ?>
                                    <br><img src="<?= asset_url(); ?>images/bahu-kiri.png" width="150"><br />
                                    batas bawah = <?= $r21->batas_bawah; ?> <?= $r->satuan_variabel; ?><br />
                                    batas atas = <?= $r22->batas_atas; ?> <?= $r->satuan_variabel; ?>
                                    <p>
                                        Keterangan: <br>
                                        <?= ($r->keterangan1 == "") ? "-" : $r->keterangan1; ?>
                                    </p>
                                </td>
                                <td>
                                    <?= $r22->nama_himpunan; ?>
                                    <br><img src="<?= asset_url(); ?>images/bahu-kanan.png" width="150"><br />
                                    batas bawah = <?= $r21->batas_bawah; ?> <?= $r->satuan_variabel; ?><br />
                                    batas atas = <?= $r22->batas_atas; ?> <?= $r->satuan_variabel; ?>
                                    <p>
                                        Keterangan: <br>
                                        <?= ($r->keterangan2 == "") ? "-" : $r->keterangan2; ?>
                                    </p>
                                </td> -->
                            </tr>
                        </table>
                    </td>
                </tr>
            <?php } ?>
            <tr>
                <td colspan="3">
                    <input class="btn btn-primary btn-block" type="submit" name="button" value="Proses">
                </td>
            </tr>
            <?php
            $q = "SELECT * FROM variabel WHERE status_variabel='output' ORDER BY id_variabel";
            $r = $ci->db->query($q)->row();
            ?>
            <!-- <tr>
                <td>DICARI NILAI</td>
                <td><?= $r->nama_variabel; ?> = ? <?= $r->satuan_variabel; ?></td>
                <td>
                    <?php
                    $q211 = "SELECT * FROM himpunan WHERE id_variabel='$r->id_variabel' ORDER BY FIELD(status_himpunan, 'bahu kiri', 'bahu kanan') ASC";
                    $q222 = "SELECT * FROM himpunan WHERE id_variabel='$r->id_variabel' ORDER BY FIELD(status_himpunan, 'bahu kiri', 'bahu kanan') DESC";
                    //echo "SELECT * FROM himpunan WHERE id_variabel='$r->id_variabel]' ORDER BY FIELD(status_himpunan, 'bahu kiri', 'bahu kanan')";
                    $r211 = $ci->db->query($q211)->row();
                    $r222 = $ci->db->query($q222)->row();
                    ?>
                    <table class="table">
                        <tr>
                            <td>
                                <?= $r211->nama_himpunan; ?>
                                <br><img src="<?= asset_url(); ?>images/bahu-kiri.png" width="150"><br />
                                batas bawah = <?= $r211->batas_bawah; ?> <?= $r->satuan_variabel; ?><br />
                                batas atas = <?= $r211->batas_atas; ?> <?= $r->satuan_variabel; ?>
                            </td>
                            <td>
                                <?= $r222->nama_himpunan; ?>
                                <br><img src="<?= asset_url(); ?>images/bahu-kanan.png" width="150"><br />
                                batas bawah = <?= $r222->batas_bawah; ?> <?= $r->satuan_variabel; ?><br />
                                batas atas = <?= $r222->batas_atas; ?> <?= $r->satuan_variabel; ?>
                            </td>
                        </tr>
                    </table>
                </td>
            </tr> -->
        </table>
        <br>
    </form>
<?php
} else {
?>
    <div id="perhitungan" style="display:none;">
        <table class="table table-sm table-bordered table-striped">
            <tr>
                <td>NAMA VARIABEL</td>
                <td>KURVA</td>
            </tr>
            <?php
            $q = "SELECT * FROM variabel WHERE status_variabel='input' ORDER BY id_variabel";
            foreach ($ci->db->query($q)->result() as $r) {
            ?>
                <tr>
                    <td><?= $r->nama_variabel; ?></td>
                    <td>
                        <?php
                        $q2 = "SELECT * FROM himpunan WHERE id_variabel='$r->id_variabel' ORDER BY FIELD(status_himpunan, 'bahu kiri', 'bahu kanan')";
                        //echo "SELECT * FROM himpunan WHERE id_variabel='$r->id_variabel]' ORDER BY FIELD(status_himpunan, 'bahu kiri', 'bahu kanan')";
                        $r2 = $ci->db->query($q2)->row();
                        ?>
                        <table class="table">
                            <tr>
                                <td>
                                    <?= $r2->nama_himpunan; ?><br />
                                    <img src="<?= asset_url(); ?>images/bahu-kiri.png" width="200"><br />
                                    batas bawah = <?= $r2->batas_bawah; ?> <?= $r->satuan_variabel; ?><br />
                                    batas atas = <?= $r2->batas_atas; ?> <?= $r->satuan_variabel; ?>
                                </td>
                                <?php
                                $r2 = $ci->db->query($q2)->row();
                                ?>
                                <td>
                                    <?= $r2->nama_himpunan; ?><br />
                                    <img src="<?= asset_url(); ?>images/bahu-kanan.png" width="200"><br />
                                    batas bawah = <?= $r2->batas_bawah; ?> <?= $r->satuan_variabel; ?><br />
                                    batas atas = <?= $r2->batas_atas; ?> <?= $r->satuan_variabel; ?>
                                </td>
                            </tr>
                            <?php
                            $q2 = "SELECT * FROM himpunan WHERE id_variabel='$r->id_variabel' ORDER BY FIELD(status_himpunan, 'bahu kiri', 'bahu kanan')";
                            //echo "SELECT * FROM himpunan WHERE id_variabel='$r->id_variabel]' ORDER BY FIELD(status_himpunan, 'bahu kiri', 'bahu kanan')";
                            $r2 = $ci->db->query($q2)->row();
                            ?>
                            <tr>
                                <td>
                                    Rumus <?= $r2->nama_himpunan; ?><br />
                                    x<=<?= $r2->batas_bawah; ?> ---> Miu(u)=1<br />
                                        <?= $r2->batas_bawah; ?><=x<=<?= $r2->batas_atas; ?> ---> Miu(u)=(<?= $r2->batas_atas; ?>-x)/(<?= $r2->batas_atas; ?>-<?= $r2->batas_bawah; ?>)<br />
                                            x>=<?= $r2->batas_atas; ?> ---> Miu(u)=0
                                </td>
                                <?php
                                $r2 = $ci->db->query($q2)->row();
                                ?>
                                <td>
                                    Rumus <?= $r2->nama_himpunan; ?><br />
                                    x<=<?= $r2->batas_bawah; ?> ---> Miu(u)=0<br />
                                        <?= $r2->batas_bawah; ?><=x<=<?= $r2->batas_atas; ?> ---> Miu(u)=(x-<?= $r2->batas_bawah; ?>)/(<?= $r2->batas_atas; ?>-<?= $r2->batas_bawah; ?>)<br />
                                            x>=<?= $r2->batas_atas; ?> ---> Miu(u)=1
                                </td>
                            </tr>
                        </table>
                    </td>
                </tr>
            <?php } ?>
            <?php
            $q = "SELECT * FROM variabel WHERE status_variabel='output' ORDER BY id_variabel";
            $r = $ci->db->query($q)->row();
            ?>
            <tr>
                <td>DICARI NILAI <?= $r->nama_variabel; ?> = ? <?= $r->satuan_variabel; ?></td>
                <td>
                    <?php
                    $q2 = "SELECT * FROM himpunan WHERE id_variabel='$r->id_variabel' ORDER BY FIELD(status_himpunan, 'bahu kiri', 'bahu kanan')";
                    //echo "SELECT * FROM himpunan WHERE id_variabel='$r->id_variabel]' ORDER BY FIELD(status_himpunan, 'bahu kiri', 'bahu kanan')";
                    $r2 = $ci->db->query($q2)->row();
                    ?>
                    <table class="table">
                        <tr>
                            <td>
                                <?= $r2->nama_himpunan; ?><br />
                                <img src="<?= asset_url(); ?>images/bahu-kiri.png" width="200"><br />
                                batas bawah = <?= $r2->batas_bawah; ?> <?= $r->satuan_variabel; ?><br />
                                batas atas = <?= $r2->batas_atas; ?> <?= $r->satuan_variabel; ?>
                            </td>
                            <?php
                            $r2 = $ci->db->query($q2)->row();
                            ?>
                            <td>
                                <?= $r2->nama_himpunan; ?><br />
                                <img src="<?= asset_url(); ?>images/bahu-kanan.png" width="200"><br />
                                batas bawah = <?= $r2->batas_bawah; ?> <?= $r->satuan_variabel; ?><br />
                                batas atas = <?= $r2->batas_atas; ?> <?= $r->satuan_variabel; ?>
                            </td>
                        </tr>
                        <?php
                        $q2 = "SELECT * FROM himpunan WHERE id_variabel='$r->id_variabel' ORDER BY FIELD(status_himpunan, 'bahu kiri', 'bahu kanan')";
                        //echo "SELECT * FROM himpunan WHERE id_variabel='$r->id_variabel]' ORDER BY FIELD(status_himpunan, 'bahu kiri', 'bahu kanan')";
                        $r2 = $ci->db->query($q2)->row();
                        ?>
                        <tr>
                            <td>
                                Rumus <?= $r2->nama_himpunan; ?><br />
                                a=(<?= $r2->batas_atas; ?>-z)/(<?= $r2->batas_atas; ?>-<?= $r2->batas_bawah; ?>) ---> z = 26 - (a * (26 - 18))<br />
                            </td>
                            <?php
                            $r2 = $ci->db->query($q2)->row();
                            ?>
                            <td>
                                Rumus <?= $r2->nama_himpunan; ?><br />a=(z-<?= $r2->batas_bawah; ?>)/(<?= $r2->batas_atas; ?>-<?= $r2->batas_bawah; ?>) ---> z = 18 + (a * (26 - 18))<br />
                            </td>
                        </tr>
                    </table>
                </td>
            </tr>

        </table>
        <br />
        <br />
        <table class="table table-bordered">
            <tr>
                <td>ATURAN</td>
                <?php
                $q = "SELECT * FROM variabel WHERE status_variabel = 'input' order by id_variabel";
                $i = 0;
                foreach ($ci->db->query($q)->result() as $r) {
                    $i++;
                    $q2 = "SELECT * FROM variabel WHERE id_variabel = '$r->id_variabel'";
                    $r2 = $ci->db->query($q2)->row();
                ?>
                    <td><?php if ($i == 1) {
                            echo "IF " . $r2->nama_variabel . "... ";
                        } else {
                            echo "AND " . $r2->nama_variabel . "... ";
                        } ?></td>
                <?php
                }
                $q = "SELECT * FROM variabel WHERE status_variabel = 'output'";
                $r = $ci->db->query($q)->row();
                ?>
                <td>THEN <?= $r->nama_variabel; ?>...</td>
            </tr>
            <?php
            $q = "SELECT nomor FROM aturan group by nomor order by nomor asc";
            foreach ($ci->db->query($q)->result() as $r) {
            ?>
                <tr>
                    <td><?= $r->nomor; ?></td>
                    <?php
                    $q1 = "SELECT * FROM variabel WHERE status_variabel = 'input' order by id_variabel";
                    $i = 0;
                    foreach ($ci->db->query($q1)->result() as $r1) {
                        $i++;
                        $q2 = "SELECT * FROM aturan WHERE nomor = '$r->nomor' and id_variabel = '$r1->id_variabel' order by id_variabel, id_himpunan";
                        $r2 = $ci->db->query($q2)->row();
                        $q3 = "SELECT * FROM variabel WHERE id_variabel = '$r2->id_variabel'";
                        $r3 = $ci->db->query($q3)->row();
                        $q4 = "SELECT * FROM himpunan WHERE id_himpunan = '$r2->id_himpunan'";
                        $r4 = $ci->db->query($q4)->row();
                    ?>
                        <td><?php if ($i == 1) {
                                echo "IF " . $r3->nama_variabel . " " . $r4->nama_himpunan . " ";
                            } else {
                                echo "AND " . $r3->nama_variabel . " " . $r4->nama_himpunan . " ";
                            } ?></td>
                    <?php
                    }
                    $q1 = "SELECT * FROM variabel WHERE status_variabel = 'output'";
                    $r1 = $ci->db->query($q1)->row();
                    $q2 = "SELECT * FROM aturan WHERE nomor = '$r->nomor' and id_variabel = '$r1->id_variabel' order by id_variabel, id_himpunan";
                    $r2 = $ci->db->query($q2)->row();
                    $q3 = "SELECT * FROM variabel WHERE id_variabel = '$r2->id_variabel'";
                    $r3 = $ci->db->query($q3)->row();
                    $q4 = "SELECT * FROM himpunan WHERE id_himpunan = '$r2->id_himpunan'";
                    $r4 = $ci->db->query($q4)->row();
                    ?>
                    <td><?= $r3->nama_variabel . " " . $r4->nama_himpunan ?></td>
                </tr>
            <?php
            }
            ?>
        </table>


        <br />
        Diketahui :<br />
        <?php
        $q = "SELECT * FROM variabel WHERE status_variabel='input' ORDER BY id_variabel";
        foreach ($ci->db->query($q)->result() as $r) {
            echo $r->nama_variabel . " = " . $_POST['variabel' . $r->id_variabel] . " " . $r->satuan_variabel . "<br/>";
        }
        ?>
        <br />
        <br />
        <?php
        $i = -1;
        $batas_bawah = array();
        $z = array();
        $z_total = 0;
        $a_total = 0;
        $q0 = "SELECT nomor FROM aturan group by nomor order by nomor asc";
        foreach ($ci->db->query($q0)->result() as $r0) {
            $i++;
            echo "Proses Aturan Nomor " . $r0->nomor . '<br/>';
        ?>
            <table class="table table-sm table-bordered table-striped">
                <?php
                $k = 0;
                $q1 = "SELECT * FROM variabel WHERE status_variabel='input' ORDER BY id_variabel";
                foreach ($ci->db->query($q1)->result() as $r1) {
                    $k++;
                    $q2 = "SELECT * FROM aturan WHERE nomor = '$r0->nomor' and id_variabel = '$r1->id_variabel'";
                    $r2 = $ci->db->query($q2)->row();
                    $q3 = "SELECT * FROM variabel WHERE id_variabel = '$r2->id_variabel'";
                    $r3 = $ci->db->query($q3)->row();
                    $q4 = "SELECT * FROM himpunan WHERE id_himpunan = '$r2->id_himpunan'";
                    $r4 = $ci->db->query($q4)->row();
                ?>
                    <td><?php if ($k == 1) {
                            echo "IF " . $r3->nama_variabel . " " . $r4->nama_himpunan . " ";
                        } else {
                            echo "AND " . $r3->nama_variabel . " " . $r4->nama_himpunan . " ";
                        } ?></td>
                <?php
                }
                $q1 = "SELECT * FROM variabel WHERE status_variabel = 'output'";
                $r1 = $ci->db->query($q1)->row();
                $q2 = "SELECT * FROM aturan WHERE nomor = '$r0->nomor' and id_variabel = '$r1->id_variabel' order by id_variabel, id_himpunan";
                $r2 = $ci->db->query($q2)->row();
                $q3 = "SELECT * FROM variabel WHERE id_variabel = '$r2->id_variabel'";
                $r3 = $ci->db->query($q3)->row();
                $q4 = "SELECT * FROM himpunan WHERE id_himpunan = '$r2->id_himpunan'";
                $r4 = $ci->db->query($q4)->row();
                ?>
                <td><?= $r3->nama_variabel . " " . $r4->nama_himpunan ?></td>
                </tr>
            </table>
            <table class="table table-sm table-bordered table-striped">
                <tr>
                    <td>ATURAN <?= $r0->nomor; ?></td>
                    <td>RUMUS</td>
                    <td>PERHITUNGAN</td>
                </tr>
                <?php
                $a[$i] = 0;
                $c = -1;
                unset($strmiu);
                $strmiu = array();
                $q = "SELECT * FROM variabel WHERE status_variabel='input' ORDER BY id_variabel";
                foreach ($ci->db->query($q)->result() as $r) {
                    $c++;
                ?>
                    <tr>
                        <td>
                            <?= $r->nama_variabel; ?><br />
                        </td>
                        <td>
                            <?php
                            $q4 = "SELECT * FROM aturan WHERE id_variabel='$r->id_variabel' and nomor='$r0->nomor'";
                            $r4 = $ci->db->query($q4)->row();
                            $q2 = "SELECT * FROM himpunan WHERE id_variabel='$r->id_variabel' and id_himpunan='$r4->id_himpunan'";
                            $r2 = $ci->db->query($q2)->row();
                            ?>
                            <table class="table">
                                <tr>
                                    <?php
                                    if ($r2->status_himpunan == 'bahu kiri') {
                                    ?>
                                        <td>
                                            <?= $r2->nama_himpunan; ?><br />
                                            <img src="<?= asset_url(); ?>images/bahu-kiri.png" width="200"><br />
                                            batas bawah = <?= $r2->batas_bawah; ?> <?= $r->satuan_variabel; ?><br />
                                            batas atas = <?= $r2->batas_atas; ?> <?= $r->satuan_variabel; ?><br />
                                            Rumus <?= $r2->nama_himpunan; ?><br />
                                            x<=<?= $r2->batas_bawah; ?> ---> Miu(u)=1<br />
                                                <?= $r2->batas_bawah; ?><=x<=<?= $r2->batas_atas; ?> ---> Miu(u)=(<?= $r2->batas_atas; ?>-x)/(<?= $r2->batas_atas; ?>-<?= $r2->batas_bawah; ?>)<br />
                                                    x>=<?= $r2->batas_atas; ?> ---> Miu(u)=0
                                        </td>
                                    <?php
                                    } else { //if ($r2->status_himpunan == 'bahu kanan') {
                                    ?>
                                        <td>
                                            <?= $r2->nama_himpunan; ?><br />
                                            <img src="<?= asset_url(); ?>images/bahu-kanan.png" width="200"><br />
                                            batas bawah = <?= $r2->batas_bawah; ?> <?= $r->satuan_variabel; ?><br />
                                            batas atas = <?= $r2->batas_atas; ?> <?= $r->satuan_variabel; ?><br />
                                            Rumus <?= $r2->nama_himpunan; ?><br />
                                            x<=<?= $r2->batas_bawah; ?> ---> Miu(u)=0<br />
                                                <?= $r2->batas_bawah; ?><=x<=<?= $r2->batas_atas; ?> ---> Miu(u)=(x-<?= $r2->batas_bawah; ?>)/(<?= $r2->batas_atas; ?>-<?= $r2->batas_bawah; ?>)<br />
                                                    x>=<?= $r2->batas_atas; ?> ---> Miu(u)=1
                                        </td>
                                    <?php
                                    }
                                    ?>
                                </tr>
                            </table>
                        </td>
                        <?php
                        if ($r2->status_himpunan == 'bahu kiri') {
                        ?>
                            <td>
                                <?php
                                if ($_POST['variabel' . $r->id_variabel] <= $r2->batas_bawah) {
                                    $nilai_a = 1;
                                    echo "x <= " . $r2->batas_bawah . "<br/>";
                                    echo "Miu(u) = " . $nilai_a;
                                } else if (($_POST['variabel' . $r->id_variabel] >= $r2->batas_bawah) && ($_POST['variabel' . $r->id_variabel] <= $r2->batas_atas)) {
                                    $nilai_a = (($r2->batas_atas - $_POST['variabel' . $r->id_variabel]) / ($r2->batas_atas - $r2->batas_bawah));
                                    echo $r2->batas_bawah . " <= x <= " . $r2->batas_atas . "<br/>";
                                    echo "Miu(u) = (" . $r2->batas_atas . " - " . $_POST['variabel' . $r->id_variabel] . ") / (" . $r2->batas_atas . " - " . $r2->batas_bawah . ") = " . $nilai_a;
                                } else { //if ($_POST['variabel'.$r->id_variabel] >= $r2->batas_atas) {
                                    $nilai_a = 0;
                                    echo "x >= " . $r2->batas_atas . "<br/>";
                                    echo "Miu(u) = " . $nilai_a;
                                }

                                $strmiu[$c] = $nilai_a;
                                if (($c == 0) || ($a[$i] > $nilai_a)) {
                                    $a[$i] = $nilai_a;
                                }
                                ?>
                            </td>
                        <?php
                        } else { //if ($r2->status_himpunan == 'bahu kanan') {
                        ?>
                            <td>
                                <?php
                                if ($_POST['variabel' . $r->id_variabel] <= $r2->batas_bawah) {
                                    $nilai_a = 0;
                                    echo "x <= " . $r2->batas_bawah . "<br/>";
                                    echo "Miu(u) = " . $nilai_a;
                                } else if (($_POST['variabel' . $r->id_variabel] >= $r2->batas_bawah) && ($_POST['variabel' . $r->id_variabel] <= $r2->batas_atas)) {
                                    $nilai_a = (($_POST['variabel' . $r->id_variabel] - $r2->batas_bawah) / ($r2->batas_atas - $r2->batas_bawah));
                                    echo $r2->batas_bawah . " <= x <= " . $r2->batas_atas . "<br/>";
                                    echo "Miu(u) = (" . $r2->batas_atas . " - " . $_POST['variabel' . $r->id_variabel] . ") / (" . $r2->batas_atas . " - " . $r2->batas_bawah . ") = " . $nilai_a;
                                } else { //if ($_POST['variabel'.$r->id_variabel] >= $r2->batas_atas) {
                                    $nilai_a = 1;
                                    echo "x >= " . $r2->batas_atas . "<br/>";
                                    echo "Miu(u) = " . $nilai_a;
                                }

                                $strmiu[$c] = $nilai_a;
                                if (($c == 0) || ($a[$i] > $nilai_a)) {
                                    $a[$i] = $nilai_a;
                                }
                                ?>
                            </td>
                        <?php
                        }
                        ?>
                    </tr>
                <?php } ?>
                <?php
                $q = "SELECT * FROM variabel WHERE status_variabel='output' ORDER BY id_variabel";
                $r = $ci->db->query($q)->row();
                ?>
                <tr>

                    <td><?= $r->nama_variabel; ?> = </td>
                    <td>
                        <?php
                        $q4 = "SELECT * FROM aturan WHERE id_variabel='$r->id_variabel' and nomor='$r0->nomor'";
                        $r4 = $ci->db->query($q4)->row();
                        $q2 = "SELECT * FROM himpunan WHERE id_variabel='$r->id_variabel' and id_himpunan='$r4->id_himpunan'";
                        $r2 = $ci->db->query($q2)->row();
                        ?>
                        <table class="table">
                            <tr>
                                <?php
                                if ($r2->status_himpunan == 'bahu kiri') {
                                ?>
                                    <td>
                                        <?= $r2->nama_himpunan; ?><br />
                                        <img src="<?= asset_url(); ?>images/bahu-kiri.png" width="200"><br />
                                        batas bawah = <?= $r2->batas_bawah; ?> <?= $r->satuan_variabel; ?><br />
                                        batas atas = <?= $r2->batas_atas; ?> <?= $r->satuan_variabel; ?><br />
                                        Rumus <?= $r2->nama_himpunan; ?><br />
                                        a=(<?= $r2->batas_atas; ?>-z)/(<?= $r2->batas_atas; ?>-<?= $r2->batas_bawah; ?>) ---> z = 26 - (a * (26 - 18))<br />
                                    </td>
                                <?php
                                } else if ($r2->status_himpunan == 'bahu kanan') {
                                ?>
                                    <td>
                                        <?= $r2->nama_himpunan; ?><br />
                                        <img src="<?= asset_url(); ?>images/bahu-kanan.png" width="200"><br />
                                        batas bawah = <?= $r2->batas_bawah; ?> <?= $r->satuan_variabel; ?><br />
                                        batas atas = <?= $r2->batas_atas; ?> <?= $r->satuan_variabel; ?><br />
                                        Rumus <?= $r2->nama_himpunan; ?><br />a=(z-<?= $r2->batas_bawah; ?>)/(<?= $r2->batas_atas; ?>-<?= $r2->batas_bawah; ?>) ---> z = 18 + (a * (26 - 18))<br />
                                    </td>
                                <?php
                                }
                                ?>
                            </tr>
                        </table>
                    </td>
                    <td><?php
                        if ($r2->status_himpunan == 'bahu kiri') {
                            $z[$i] = $r2->batas_atas - ($a[$i] * ($r2->batas_atas - $r2->batas_bawah));
                        } else if ($r2->status_himpunan == 'bahu kanan') {
                            $z[$i] = $r2->batas_bawah + ($a[$i] * ($r2->batas_atas - $r2->batas_bawah));
                        }
                        $a_total = $a_total + $a[$i];
                        $z_total = $z_total + ($a[$i] * $z[$i]);
                        echo "a" . ($i + 1) . " = min(" . implode(";", $strmiu) . ") = " . $a[$i] . "<br/>";
                        if ($r2->status_himpunan == 'bahu kiri') {
                            echo "z" . ($i + 1) . " = " . $r2->batas_atas . " - (" . $a[$i] . " * (" . $r2->batas_atas . " - " . $r2->batas_bawah . ")) = " . $z[$i] . "<br/>";
                        } else if ($r2->status_himpunan == 'bahu kanan') {
                            echo "z" . ($i + 1) . " = " . $r2->batas_atas . " + (" . $a[$i] . " * (" . $r2->batas_atas . " - " . $r2->batas_bawah . ")) = " . $z[$i] . "<br/>";
                        }
                        ?></td>
                </tr>
            </table>
            <br />
        <?php
        }

        $z_total = $z_total / $a_total;
        echo "Atotal = " . implode("+", $a) . " = " . $a_total . "<br/>";
        echo "Ztotal = (" . implode("+", $z) . ") / (" . implode("+", $a) . ") = " . $z_total . "<br/>";
        ?>
    </div>
    <br />
    <input class="btn btn-primary" type="button" value="Perhitungan" onclick="document.getElementById('perhitungan').style.display='block';" />
    <br />
    <br />
    <table class="table table-bordered table-striped table-sm">
        <thead>
            <tr>
                <th colspan=3>Data Proposal</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td width="300px">NIK</td>
                <td width="20px">:</td>
                <td><?= $this->input->post('nik') ?></td>
            </tr>
            <tr>
                <td>Nama Lengkap Sesuai KTP</td>
                <td>:</td>
                <td><?= $this->input->post('nama_lengkap') ?></td>
            </tr>
            <tr>
                <td>Jenis Kelamin</td>
                <td>:</td>
                <td><?= $this->input->post('jenis_kelamin') ?></td>
            </tr>
            <tr>
                <td>Tempat & Tangal Lahir</td>
                <td>:</td>
                <td><?= $this->input->post('tempat_lahir') ?>, <?= $this->input->post('tgl_lahir') ?></td>
            </tr>
            <tr>
                <td>Alamat</td>
                <td>:</td>
                <td><?= $this->input->post('alamat') ?></td>
            </tr>
            <tr>
                <td>Nama Usaha</td>
                <td>:</td>
                <td><?= $this->input->post('nama_usaha') ?></td>
            </tr>
            <tr>
                <td>Deskripsi Usaha</td>
                <td>:</td>
                <td><?= $this->input->post('deskripsi_usaha') ?></td>
            </tr>
            <?php
            $variabel = "";
            $data_variabel = [];
            $q = "SELECT * FROM variabel WHERE status_variabel='input' ORDER BY id_variabel";
            foreach ($ci->db->query($q)->result() as $r) { ?>

                <tr>
                    <td><?= $r->nama_variabel; ?> (<?= $r->satuan_variabel ?>)</th>
                    <td>:</td>
                    <td><?= decimal($this->input->post('variabel' . $r->id_variabel), 0) ?> </td>
                </tr>

            <?php $variabel .= $r->nama_variabel . '(' . $r->satuan_variabel . ') : ' . $this->input->post('variabel' . $r->id_variabel) . ' | ';
                $data_variabel[] =  decimal($this->input->post('variabel' . $r->id_variabel), 0);
            }
            ?>
            <?php
            $q = "SELECT * FROM variabel WHERE status_variabel='output' ORDER BY id_variabel";
            $r = $ci->db->query($q)->row();
            ?>
            <tr>
                <td colspan="1"><?= $r->nama_variabel; ?></td>
                <td>:</td>
                <th><?= $z_total; ?><?= $r->satuan_variabel; ?></th>
            </tr>

        </tbody>
    </table>

    <form method="POST" action="<?= site_url('admin/tsukamoto/save') ?>" id="formSubmitProposal" enctype="multipart/form-data">
        <input class="form-control" type="hidden" name="nik" id="nik" value="<?= $this->input->post('nik') ?>">
        <input class="form-control" type="hidden" name="nama_lengkap" id="nama_lengkap" value="<?= $this->input->post('nama_lengkap') ?>">
        <input class="form-control" type="hidden" name="jenis_kelamin" id="jenis_kelamin" value="<?= $this->input->post('jenis_kelamin') ?>">
        <input class="form-control" type="hidden" name="tempat_lahir" id="tempat_lahir" value="<?= $this->input->post('tempat_lahir') ?>">
        <input class="form-control" type="hidden" name="tgl_lahir" id="tgl_lahir" value="<?= $this->input->post('tgl_lahir') ?>">
        <input class="form-control" type="hidden" name="alamat" id="alamat" value="<?= $this->input->post('alamat') ?>">
        <input class="form-control" type="hidden" name="nama_usaha" id="nama_usaha" value="<?= $this->input->post('nama_usaha') ?>">
        <input class="form-control" type="hidden" name="deskripsi_usaha" id="deskripsi_usaha" value="<?= $this->input->post('deskripsi_usaha') ?>">

        <div class="form-group">
            <label for="proposal_usaha">Proposal Usaha</label>
            <input class="form-control" type="file" name="proposal_usaha" id="proposal_usaha" value="<?= $this->input->post('proposal_usaha') ?>">
        </div>

        <input class="form-control" type="hidden" name="data_variabel" id="data_variabel" value="<?= implode(",", $data_variabel) ?>">

        <textarea class="form-control" hidden name="variabel" id="variabel" rows="3"><?= $variabel ?></textarea>

        <input class="form-control" type="hidden" name="output" id="output" value="<?= $z_total ?>">
        <button type="submit" class="btn btn-primary"><i class="fas fa-save fa-sm fa-fw"></i> Submit Data</button>
    </form>

<?php } ?>