<!-- Sidebar - Brand -->
<a class="sidebar-brand d-flex align-items-center justify-content-center">
    <div class="sidebar-brand-icon rotate-n-15xxx">
        <!-- <i class="fas fa-laugh-wink"></i> -->
        <img src="<?= asset_url(); ?>/images/logo.png" width="100%" alt="">
    </div>
    <div class="sidebar-brand-text mx-3xxx"> <sup></sup></div>
</a>

<!-- Divider -->
<hr class="sidebar-divider my-0">

<li class="nav-item <?= ($content == "view_admin") ? "active" : "" ?>">
    <a class="nav-link" href="<?= site_url('admin/home'); ?>">
        <i class="fas fa-fw fa-tachometer-alt"></i>
        <span>Home</span>
    </a>
</li>

<?php
$arr_user = ['view_user'];
$arr_variabel = ['view_variabel', 'view_detail_variabel'];
$arr_aturan = ['view_aturan'];
$arr_proposal = ['view_proposal'];
$arr_master = array_merge($arr_user, $arr_variabel, $arr_aturan, $arr_proposal);
?>
<li class="nav-item <?= in_array($content, $arr_master) ? "active" : "" ?>">
    <a class="nav-link" href="#" data-toggle="collapse" data-target="#arr_master" aria-expanded="true" aria-controls="arr_master">
        <i class="fas fa-fw fa-th-large" aria-hidden="true"></i>
        <span>Data Master</span>
    </a>
    <div id="arr_master" class="collapse <?= in_array($content, $arr_master) ? "show" : "" ?>" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
        <div class="bg-white py-2 collapse-inner rounded">
            <!-- <h6 class="collapse-header">Custom Components:</h6> -->
            <a class="collapse-item <?= in_array($content, $arr_user) ? "active" : "" ?>" href="<?= site_url('admin/user'); ?>">Data User</a>
            <a class="collapse-item <?= in_array($content, $arr_proposal) ? "active" : "" ?>" href="<?= site_url('admin/proposal'); ?>">Data Proposal</a>
            <a class="collapse-item <?= in_array($content, $arr_variabel) ? "active" : "" ?>" href="<?= site_url('admin/variabel'); ?>">Data Variabel</a>
            <a class="collapse-item <?= in_array($content, $arr_aturan) ? "active" : "" ?>" href="<?= site_url('admin/aturan'); ?>">Data Aturan</a>
        </div>
    </div>
</li>

<!-- Divider -->
<hr class="sidebar-divider d-none d-md-block">

<?php
$arr_tsukamoto = ['view_tsukamoto', 'view_detail_tsukamoto'];
?>
<li class="nav-item <?= (in_array($content, $arr_tsukamoto)) ? "active" : "" ?>">
    <a class="nav-link" href="<?= site_url('admin/tsukamoto'); ?>">
        <i class="fas fa-fw fa-users"></i>
        <span>Input Data Proposal</span>
    </a>
</li>