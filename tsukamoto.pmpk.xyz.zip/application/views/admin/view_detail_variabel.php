<br />
<strong><?= $title ?></strong><br />

<hr />
<?php
$id_variabel = $rowvariabel->id_variabel;
?>
<table class="table table-sm">
    <tbody>
        <tr>
            <td scope="row">ID Variabel</td>
            <td>:</td>
            <td><?= $id_variabel ?></td>
        </tr>
        <tr>
            <td scope="row">Nama Variabel</td>
            <td>:</td>
            <td><?= $rowvariabel->nama_variabel; ?></td>
        </tr>
        <tr>
            <td scope="row">Satuan Variabel</td>
            <td>:</td>
            <td><?= $rowvariabel->satuan_variabel ?></td>
        </tr>
        <tr>
            <td scope="row">Status Variabel</td>
            <td>:</td>
            <td><?= $rowvariabel->status_variabel ?></td>
        </tr>
        <tr>
            <td scope="row">Keterangan 1</td>
            <td>:</td>
            <td><?= $rowvariabel->keterangan1 ?></td>
        </tr>
        <tr>
            <td scope="row">Keterangan 2</td>
            <td>:</td>
            <td><?= $rowvariabel->keterangan2 ?></td>
        </tr>
    </tbody>
</table>

<!-- Button trigger editVariabel<?= $rowvariabel->id_variabel; ?> -->
<button type="button" class="btn btn-warning" data-toggle="modal" data-target="#editVariabel<?= $rowvariabel->id_variabel; ?>">
    <i class="fas fa-edit"></i> Edit Variabel
</button>

<!-- editVariabel<?= $rowvariabel->id_variabel; ?> -->
<div class="modal fade" id="editVariabel<?= $rowvariabel->id_variabel; ?>" tabindex="-1" role="dialog" aria-labelledby="editVariabel<?= $rowvariabel->id_variabel; ?>Label" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="editVariabel<?= $rowvariabel->id_variabel; ?>Label">Edit Variabel</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form method="POST" action="<?= site_url('admin/variabel/update') ?>" id="formEditVariabel<?= $rowvariabel->id_variabel; ?>">
                    <input type="hidden" class="form-control" name="id_variabel" required value="<?= $rowvariabel->id_variabel; ?>">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group row">
                                    <div class="col-md-12">
                                        <label for="nama_variabel">Nama Variabel</label>
                                        <input type="text" class="form-control" name="nama_variabel" required value="<?= $rowvariabel->nama_variabel; ?>">
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-12">
                                <div class="form-group row">
                                    <div class="col-md-12">
                                        <label for="satuan_variabel">Satuan Variabel</label>
                                        <input type="text" class="form-control" name="satuan_variabel" required value="<?= $rowvariabel->satuan_variabel; ?>">
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-12">
                                <div class="form-group row">
                                    <div class="col-md-12">
                                        <label for="status_variabel">Status Variabel</label>
                                        <select class="form-control" name="status_variabel" id="status_variabel">
                                            <option value="">Pilih Status Variabel</option>
                                            <?php foreach ($status_variabel as $item) : ?>
                                                <option value="<?= $item ?>" <?= ($item == $rowvariabel->status_variabel) ? "selected" : "" ?>><?= $item ?></option>
                                            <?php endforeach ?>
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-12">
                                <div class="form-group row">
                                    <div class="col-md-12">
                                        <label for="keterangan1">Keterangan 1</label>
                                        <textarea class="form-control" name="keterangan1" id="keterangan1"><?= $rowvariabel->keterangan1; ?></textarea>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-12">
                                <div class="form-group row">
                                    <div class="col-md-12">
                                        <label for="keterangan2">Keterangan 2</label>
                                        <textarea class="form-control" name="keterangan2" id="keterangan2"><?= $rowvariabel->keterangan2; ?></textarea>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-primary" form="formEditVariabel<?= $rowvariabel->id_variabel; ?>"><i class="fas fa-save"></i> Save</button>
            </div>
        </div>
    </div>
</div>

<a onclick="return confirm('Hapus data?');" class="btn btn-danger" href="<?php echo site_url('admin/variabel/delete/' . $rowvariabel->id_variabel); ?>"><i class="fas fa-trash"></i> Hapus Variabel</a>
<hr>

<!-- Button trigger tambahHimpunan -->
<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#tambahHimpunan">
    <i class="fas fa-plus"></i> Tambah Himpunan
</button>

<!-- tambahHimpunan -->
<div class="modal fade" id="tambahHimpunan" tabindex="-1" role="dialog" aria-labelledby="tambahHimpunanLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="tambahHimpunanLabel">Tambah Himpunan</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">

                <form method="POST" action="<?= site_url('admin/variabel/savehimpunan') ?>" id="formTambahHimpunan">
                    <input type="hidden" class="form-control" name="id_variabel" required value="<?= $id_variabel ?>">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group row">
                                    <div class="col-md-12">
                                        <label for="nama_himpunan">Nama Himpunan</label>
                                        <input type="text" class="form-control" name="nama_himpunan" required>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-12">
                                <div class="form-group row">
                                    <div class="col-md-12">
                                        <label for="batas_bawah">Batas Bawah</label>
                                        <input type="number" class="form-control" name="batas_bawah" required>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-12">
                                <div class="form-group row">
                                    <div class="col-md-12">
                                        <label for="batas_atas">Batas Atas</label>
                                        <input type="number" class="form-control" name="batas_atas" required>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label for="status_himpunan">Status Himpunan</label>
                                    <select class="form-control" name="status_himpunan" id="status_himpunan">
                                        <?php foreach ($status_himpunan as $item) : ?>
                                            <option value="<?= $item ?>"><?= $item ?></option>
                                        <?php endforeach ?>
                                    </select>
                                </div>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-primary" form="formTambahHimpunan"><i class="fas fa-save"></i> Save</button>
            </div>
        </div>
    </div>
</div>

<hr>
<div class="table-responsive">
    <?= $this->session->flashdata('message'); ?>
    <table class="table table-sm table-bordered table-striped nw" id="dataTable" width="100%" cellspacing="0">
        <thead>
            <tr>
                <th>No</th>
                <th>Nama Himpunan</th>
                <th>Batas Bawah </th>
                <th>Batas Atas </th>
                <th>Status Himpunan</th>
                <th></th>
            </tr>
        </thead>
        <tbody>
            <?php
            $no = 1;
            foreach ($tabelhimpunan as $rowhimpunan) {
                $id_himpunan = $rowhimpunan->id_himpunan; ?>
                <tr title="<?= $id_himpunan; ?>">
                    <td><?= $no++; ?></td>
                    <td><?= $rowhimpunan->nama_himpunan; ?></td>
                    <td><?= $rowhimpunan->batas_bawah; ?></td>
                    <td><?= $rowhimpunan->batas_atas; ?></td>
                    <td><?= $rowhimpunan->status_himpunan; ?></td>
                    <td>
                        <!-- Button trigger editHimpunan<?= $id_himpunan; ?> -->
                        <button type="button" class="btn btn-warning btn-sm" data-toggle="modal" data-target="#editHimpunan<?= $id_himpunan; ?>">
                            <i class="fas fa-edit"></i>
                        </button>

                        <!-- editHimpunan<?= $id_himpunan; ?> -->
                        <div class="modal fade" id="editHimpunan<?= $id_himpunan; ?>" tabindex="-1" role="dialog" aria-labelledby="editHimpunan<?= $id_himpunan; ?>Label" aria-hidden="true">
                            <div class="modal-dialog" role="document">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="editHimpunan<?= $id_himpunan; ?>Label">Edit Himpunan</h5>
                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                            <span aria-hidden="true">&times;</span>
                                        </button>
                                    </div>
                                    <div class="modal-body">
                                        <form method="POST" action="<?= site_url('admin/variabel/updatehimpunan') ?>" id="formEditHimpunan<?= $id_himpunan; ?>">
                                            <input type="hidden" class="form-control" name="id_himpunan" required value="<?= $id_himpunan ?>">
                                            <input type="hidden" class="form-control" name="id_variabel" required value="<?= $id_variabel ?>">
                                            <div class="card-body">
                                                <div class="row">
                                                    <div class="col-md-12">
                                                        <div class="form-group row">
                                                            <div class="col-md-12">
                                                                <label for="nama_himpunan">Nama Himpunan</label>
                                                                <input type="text" class="form-control" name="nama_himpunan" required value="<?= $rowhimpunan->nama_himpunan ?>">
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-12">
                                                        <div class="form-group row">
                                                            <div class="col-md-12">
                                                                <label for="batas_bawah">Batas Bawah</label>
                                                                <input type="number" class="form-control" name="batas_bawah" required value="<?= $rowhimpunan->batas_bawah ?>">
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-12">
                                                        <div class="form-group row">
                                                            <div class="col-md-12">
                                                                <label for="batas_atas">Batas Atas</label>
                                                                <input type="number" class="form-control" name="batas_atas" required value="<?= $rowhimpunan->batas_atas ?>">
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-12">
                                                        <div class="form-group">
                                                            <label for="status_himpunan">Status Himpunan</label>
                                                            <select class="form-control" name="status_himpunan" id="status_himpunan">
                                                                <?php foreach ($status_himpunan as $item) : ?>
                                                                    <option value="<?= $item ?>" <?= $item == $rowhimpunan->status_himpunan ? "selected" : "" ?>><?= $item ?></option>
                                                                <?php endforeach ?>
                                                            </select>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </form>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                        <button type="submit" class="btn btn-primary" form="formEditHimpunan<?= $id_himpunan; ?>"><i class="fas fa-save"></i> Save</button>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <a onclick="return confirm('Hapus data?');" class="btn btn-danger btn-sm" href="<?php echo site_url('admin/variabel/deletehimpunan/' . $id_himpunan . '/' . $id_variabel); ?>"><i class="fas fa-trash"></i></a>
                    </td>
                </tr>
            <?php } ?>
        </tbody>
    </table>
</div>

<script type="text/javascript">
    $(document).ready(function() {
        $('#dataTable').DataTable({
            fixedColumns: {
                left: 0,
                right: 0
            },
            dom: 'Bfrtip',
            paging: true,
            searching: true,
            bInfo: true,
            buttons: [
                'copy',
                {
                    extend: 'excel',
                    title: '<?= $title ?> | <?= $lembaga ?>'
                },
                {
                    extend: 'pdf',
                    title: '<?= $title ?> | <?= $lembaga ?>'
                },
                {
                    extend: 'print',
                    title: '<?= $title ?> | <?= $lembaga ?>'
                }, 'colvis'
            ]
        });
    });
</script>