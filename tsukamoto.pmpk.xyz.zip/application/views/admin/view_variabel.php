<br />
<strong><?= $title ?></strong><br />
<hr />
<?= $this->session->flashdata('message'); ?>

<!-- Button trigger modal -->
<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#tambahVariabel">
    <i class="fas fa-plus"></i> Tambah Variabel
</button>

<!-- Modal -->
<div class="modal fade" id="tambahVariabel" tabindex="-1" role="dialog" aria-labelledby="tambahVariabelLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="tambahVariabelLabel">Tambah Variabel</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">

                <form method="POST" action="<?= site_url('admin/variabel/save') ?>" id="formTambahVariabel">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group row">
                                    <div class="col-md-12">
                                        <label for="nama_variabel">Nama Variabel</label>
                                        <input type="text" class="form-control" name="nama_variabel" required>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-12">
                                <div class="form-group row">
                                    <div class="col-md-12">
                                        <label for="satuan_variabel">Satuan Variabel</label>
                                        <input type="text" class="form-control" name="satuan_variabel" required>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-12">
                                <div class="form-group row">
                                    <div class="col-md-12">
                                        <label for="status_variabel">Status Variabel</label>
                                        <select class="form-control" name="status_variabel" id="status_variabel">
                                            <option value="">Pilih Status Variabel</option>
                                            <?php foreach ($status_variabel as $item) : ?>
                                                <option value="<?= $item ?>"><?= $item ?></option>
                                            <?php endforeach ?>
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-12">
                                <div class="form-group row">
                                    <div class="col-md-12">
                                        <label for="keterangan1">Keterangan 1</label>
                                        <textarea class="form-control" name="keterangan1" id="keterangan1"></textarea>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-12">
                                <div class="form-group row">
                                    <div class="col-md-12">
                                        <label for="keterangan2">Keterangan 2</label>
                                        <textarea class="form-control" name="keterangan2" id="keterangan2"></textarea>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-primary" form="formTambahVariabel"><i class="fas fa-save"></i> Save</button>
            </div>
        </div>
    </div>
</div>

<hr>
<div class="table-responsive">
    <table class="table table-sm table-bordered table-striped nw" id="dataTable" width="100%" cellspacing="0">
        <thead>
            <tr>
                <th>No</th>
                <!-- <th>ID Variabel</th> -->
                <th>Nama Variabel</th>
                <th>Satuan Variabel</th>
                <th>Status Variabel </th>
                <th>Himpunan (Kurva) </th>
                <th>Keterangan </th>
                <th></th>
            </tr>
        </thead>
        <tbody>
            <?php $page = isset($_GET['page']) ? $_GET['page'] : 0;
            $no = $page + 1;
            foreach ($tabelvariabel as $rowvariabel) { ?>
                <tr title="<?= $rowvariabel->id_variabel; ?>">
                    <td><?= $no++; ?></td>
                    <!-- <td><?= $rowvariabel->id_variabel; ?> </td> -->
                    <td><?= $rowvariabel->nama_variabel; ?> </td>
                    <td><?= $rowvariabel->satuan_variabel; ?> </td>
                    <td><?= $rowvariabel->status_variabel; ?> </td>
                    <td>
                        <ul>
                            <?php
                            foreach ($tabelhimpunan as $rowhimpunan) {
                                if ($rowhimpunan->id_variabel == $rowvariabel->id_variabel) {
                            ?>
                                    <li>
                                        <?= $rowhimpunan->nama_himpunan ?>
                                        <ul>
                                            <li>Batas Bawah: <?= $rowhimpunan->batas_bawah ?></li>
                                            <li>Batas Atas: <?= $rowhimpunan->batas_atas ?></li>
                                            <li>Posisi Kurva: <?= $rowhimpunan->status_himpunan ?></li>
                                        </ul>
                                    </li>
                            <?php
                                }
                            }
                            ?>
                        </ul>
                    </td>
                    <td>
                        Keterangan 1: <?= $rowvariabel->keterangan1; ?> <br>
                        Keterangan 2: <?= $rowvariabel->keterangan2; ?> 
                    </td>
                    <td>
                        <a class="btn btn-info" href="<?php echo site_url('admin/variabel/detail/' . $rowvariabel->id_variabel); ?>"><i class="fas fa-search"></i></a>
                    </td>
                </tr>
            <?php } ?>
        </tbody>
    </table>
</div>

<script type="text/javascript">
    $(document).ready(function() {
        $('#dataTable').DataTable({
            fixedColumns: {
                left: 0,
                right: 0
            },
            dom: 'Bfrtip',
            paging: true,
            searching: true,
            bInfo: true,
            buttons: [
                'copy',
                {
                    extend: 'excel',
                    title: '<?= $title ?> | <?= $lembaga ?>'
                },
                {
                    extend: 'pdf',
                    title: '<?= $title ?> | <?= $lembaga ?>'
                },
                {
                    extend: 'print',
                    title: '<?= $title ?> | <?= $lembaga ?>'
                }, 'colvis'
            ]
        });
    });
</script>