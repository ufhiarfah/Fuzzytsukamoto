<?php 
$alamat = $_GET['alamat'];
$hasil_prediksi = $_GET['hasil_prediksi']; ?>
<div class="page">
    <div style="zoom:70%">
        <div id="pageHeader">
            <table width="100%">
                <tr>
                    <td valign="top" align="center">
                        <h2>DATA PROPOSAL USAHA</h2>
                        <!-- <h2></h2> -->
                    </td>
                    <!-- <td align="right">
                        <img width="150px" src="<?php echo asset_url(); ?>images/kop.png" alt="">
                    </td> -->
                </tr>
            </table>
        </div>
        <hr>
        <p align="right">
            Takalar, <?= format_tanggal(date("Y-m-d")); ?>
        </p>
        <br>
        
        <table class="table table-sm table-bordered table-striped nwxx" id="rab" width="100%" cellspacing="0">
            <thead>
                <tr>
                    <th>No</th>
                    <!-- <th>ID Proposal</th> -->
                    <th>NIK</th>
                    <th>Nama Lengkap</th>
                    <th>Jenis Kelamin </th>
                    <th>Tempat Lahir </th>
                    <th>Tanggal Lahir </th>
                    <th>Alamat </th>
                    <th>Hasil Prediksi</th>
                </tr>
            </thead>
            <tbody>
                <?php $no = 1;
                foreach ($tabelproposal as $rowproposal) { 
                    $gradehuruf = gradehuruf($rowproposal->output);
                    if ($alamat != '') {
                    if ($rowproposal->alamat == $alamat && (($hasil_prediksi == '') ? $gradehuruf != '' : $gradehuruf == $hasil_prediksi)) { ?>
                    <tr title="<?= $rowproposal->id_proposal; ?>">
                        <td><?= $no++; ?></td>
                        <!-- <td><?= $rowproposal->id_proposal; ?> </td> -->
                        <td><?= $rowproposal->nik; ?> </td>
                        <td><?= $rowproposal->nama_lengkap; ?> </td>
                        <td><?= $rowproposal->jenis_kelamin; ?> </td>
                        <td><?= $rowproposal->tempat_lahir; ?> </td>
                        <td><?= $rowproposal->tgl_lahir; ?> </td>
                        <td><?= $rowproposal->alamat; ?> </td>
                        <td><?= decimal($rowproposal->output, 2); ?>%</td>
                    </tr>
                <?php }
                    } else { ?>
                    <tr title="<?= $rowproposal->id_proposal; ?>">
                        <td><?= $no++; ?></td>
                        <!-- <td><?= $rowproposal->id_proposal; ?> </td> -->
                        <td><?= $rowproposal->nik; ?> </td>
                        <td><?= $rowproposal->nama_lengkap; ?> </td>
                        <td><?= $rowproposal->jenis_kelamin; ?> </td>
                        <td><?= $rowproposal->tempat_lahir; ?> </td>
                        <td><?= $rowproposal->tgl_lahir; ?> </td>
                        <td><?= $rowproposal->alamat; ?> </td>
                        <td><?= decimal($rowproposal->output, 2); ?>%</td>
                    </tr>
                <?php } 
                } ?>
            </tbody>
        </table>
    </div>
</div>