<br />
<strong><?= $title ?></strong><br />
<hr />

<?php
$alamat = $_GET['alamat'];
$hasil_prediksi = $_GET['hasil_prediksi']; ?>

<form action="" method="GET" class="form-inline">

    <input type="text" name="alamat" class="form-control" placeholder="Alamat" value="<?= $alamat ?>">
    &nbsp;
    <?php $arr_hp = ['Sangat Miskin', 'Miskin', 'Hampir Miskin', 'Rentan Miskin', 'Sangat Mampu']; ?>
    <select class="form-control" name="hasil_prediksi">
        <option value="">Pilih Hasil Prediksi</option>
        <?php foreach ($arr_hp as $value) : ?>
            <option value="<?= $value ?>" <?= $value == $hasil_prediksi ? "selected" : ""; ?>> <?= $value; ?></option>
        <?php endforeach ?>
    </select>
    &nbsp;
    <button type="submit" class="btn btn-primary"><i class="fa fa-search" aria-hidden="true"></i> Filter</button>
    &nbsp;
    <a href="<?= site_url() ?>admin/proposal/cetak?alamat=<?= $alamat ?>&hasil_prediksi=<?= $hasil_prediksi ?>" target="_blank" rel="noopener noreferrer" class="btn btn-primary"><i class="fa fa-print" aria-hidden="true"></i> Cetak</a>

</form>

<?= $this->session->flashdata('message'); ?>
<hr>
<div class="table-responsive">
    <table class="table table-sm table-bordered table-striped nwx" id="dataTable" width="100%" cellspacing="0">
        <thead>
            <tr>
                <th>No</th>
                <th>ID Proposal</th>
                <th>NIK</th>
                <th>Nama Lengkap</th>
                <th>Jenis Kelamin </th>
                <th>Tempat Lahir </th>
                <th>Tanggal Lahir </th>
                <th>Alamat </th>
                <th>Nama Usaha </th>
                <th>Deskripsi Usaha </th>
                <th>Proposal Usaha </th>
                <th>Hasil Prediksi</th>
                <th>Bantuan </th>
                <th></th>
            </tr>
        </thead>
        <tbody>
            <?php $no = 1;
            foreach ($tabelproposal as $rowproposal) {
                if ($alamat != '') {
                    if ($rowproposal->alamat == $alamat && (($hasil_prediksi == '') ? $gradehuruf != '' : $gradehuruf == $hasil_prediksi)) { ?>
                        <tr title="<?= $rowproposal->id_proposal; ?>">
                            <td><?= $no++; ?></td>
                            <td><?= $rowproposal->id_proposal; ?> </td>
                            <td><?= $rowproposal->nik; ?> </td>
                            <td><?= $rowproposal->nama_lengkap; ?> </td>
                            <td><?= $rowproposal->jenis_kelamin; ?> </td>
                            <td><?= $rowproposal->tempat_lahir; ?> </td>
                            <td><?= $rowproposal->tgl_lahir; ?> </td>
                            <td><?= $rowproposal->alamat; ?> </td>
                            <td><?= $rowproposal->nama_usaha; ?> </td>
                            <td><?= $rowproposal->deskripsi_usaha; ?> </td>
                            <td><a href="<?= asset_url(); ?>upload/proposal/<?= $rowproposal->proposal_usaha; ?>" target="_blank" rel="noopener noreferrer"><?= $rowproposal->proposal_usaha; ?></a> </td>
                            <td><?= decimal($rowproposal->output, 2); ?>% </td>
                            <td><?= $rowproposal->bantuan ?> </td>
                            <td>
                                <!-- Button trigger detailProposal -->
                                <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#detailProposal">
                                    <i class="fas fa-users"></i> Detail Proposal
                                </button>

                                <!-- detailProposal -->
                                <div class="modal fade" id="detailProposal" tabindex="-1" role="dialog" aria-labelledby="detailProposalLabel" aria-hidden="true">
                                    <div class="modal-dialog" role="document">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h5 class="modal-title" id="detailProposalLabel">Detail Proposal</h5>
                                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                    <span aria-hidden="true">&times;</span>
                                                </button>
                                            </div>
                                            <div class="modal-body">

                                                <div class="card-body">
                                                    <div class="row">
                                                        <div class="col-md-12">
                                                            <ul>
                                                                <?php
                                                                $variabel = explode(" | ", $rowproposal->variabel);
                                                                foreach ($variabel as $var) {
                                                                    if ($var != "") {
                                                                        $v = explode(" : ", $var); ?>
                                                                        <li><?= $v[0] ?> : <?= decimal($v[1], 0) ?></li>
                                                                <?php }
                                                                }
                                                                ?>
                                                            </ul>
                                                        </div>
                                                    </div>
                                                </div>

                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                                <button type="submit" class="btn btn-primary" form="formTambahVariabel"><i class="fas fa-save"></i> Save</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </td>
                        </tr>
                    <?php }
                } else { ?>
                    <tr title="<?= $rowproposal->id_proposal; ?>">
                        <td><?= $no++; ?></td>
                        <td><?= $rowproposal->id_proposal; ?> </td>
                        <td><?= $rowproposal->nik; ?> </td>
                        <td><?= $rowproposal->nama_lengkap; ?> </td>
                        <td><?= $rowproposal->jenis_kelamin; ?> </td>
                        <td><?= $rowproposal->tempat_lahir; ?> </td>
                        <td><?= $rowproposal->tgl_lahir; ?> </td>
                        <td><?= $rowproposal->alamat; ?> </td>
                        <td><?= $rowproposal->nama_usaha; ?> </td>
                        <td><?= $rowproposal->deskripsi_usaha; ?> </td>
                        <td><a href="<?= asset_url(); ?>upload/proposal/<?= $rowproposal->proposal_usaha; ?>" target="_blank" rel="noopener noreferrer"><?= $rowproposal->proposal_usaha; ?></a> </td>
                        <td><?= decimal($rowproposal->output, 2); ?>% </td>
                        <td><?= $rowproposal->bantuan ?> </td>
                        <td>
                            <!-- Button trigger detailProposal -->
                            <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#detailProposal">
                                <i class="fas fa-users"></i> Detail Proposal
                            </button>

                            <!-- detailProposal -->
                            <div class="modal fade" id="detailProposal" tabindex="-1" role="dialog" aria-labelledby="detailProposalLabel" aria-hidden="true">
                                <div class="modal-dialog" role="document">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h5 class="modal-title" id="detailProposalLabel">Detail Proposal</h5>
                                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                <span aria-hidden="true">&times;</span>
                                            </button>
                                        </div>
                                        <div class="modal-body">

                                            <div class="card-body">
                                                <div class="row">
                                                    <div class="col-md-12">
                                                        <ul>
                                                            <?php
                                                            $variabel = explode(" | ", $rowproposal->variabel);
                                                            foreach ($variabel as $var) {
                                                                if ($var != "") {
                                                                    $v = explode(" : ", $var); ?>
                                                                    <li><?= $v[0] ?> : <?= decimal($v[1], 0) ?></li>
                                                            <?php }
                                                            }
                                                            ?>
                                                        </ul>
                                                    </div>
                                                </div>
                                            </div>

                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                            <button type="submit" class="btn btn-primary" form="formTambahVariabel"><i class="fas fa-save"></i> Save</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </td>
                    </tr>
            <?php }
            } ?>
        </tbody>
    </table>
</div>

<script type="text/javascript">
    $(document).ready(function() {
        $('#dataTable').DataTable({
            fixedColumns: {
                left: 0,
                right: 0
            },
            dom: 'Bfrtip',
            paging: true,
            searching: true,
            bInfo: true,
            // buttons: [
            //     'copy',
            //     {
            //         extend: 'excel',
            //         title: '<?= $title ?> | <?= $lembaga ?>'
            //     },
            //     {
            //         extend: 'pdf',
            //         title: '<?= $title ?> | <?= $lembaga ?>'
            //     },
            //     {
            //         extend: 'print',
            //         title: '<?= $title ?> | <?= $lembaga ?>'
            //     }, 'colvis'
            // ]
        });
    });
</script>