<div class="page">
    <div style="zoom:70%">
        <div id="pageHeader">
            <table width="100%">
                <tr>
                    <td valign="top" align="center">
                        <h2>DATA PENDUDUK</h2>
                        <h2>DINAS SOSIAL KABUPATEN TAKALAR</h2>
                    </td>
                    <!-- <td align="right">
                        <img width="150px" src="<?php echo asset_url(); ?>images/kop.png" alt="">
                    </td> -->
                </tr>
            </table>
        </div>
        <hr>
        <p align="right">
            Takalar, <?= format_tanggal(date("Y-m-d")); ?>
        </p>
        <br>
        <table class="table table-sm table-bordered table-striped nw" id="rab" width="100%" cellspacing="0">
            <thead>
                <tr>
                    <th>No</th>
                    <th>NIK</th>
                    <th>Nama Lengkap</th>
                    <th>Jenis Kelamin </th>
                    <th>Tempat Lahir </th>
                    <th>Tanggal Lahir </th>
                    <th>Alamat </th>
                    <th>Status Kelayakan </th>
                    <th>Bantuan </th>
                </tr>
            </thead>
            <tbody>
                <?php $no = 1;
                foreach ($tabelpenduduk as $rowpenduduk) { ?>
                    <tr>
                        <td><?= $no++; ?></td>
                        <td><?= $rowpenduduk->nik; ?> </td>
                        <td><?= $rowpenduduk->nama_lengkap; ?> </td>
                        <td><?= $rowpenduduk->jenis_kelamin; ?> </td>
                        <td><?= $rowpenduduk->tempat_lahir; ?> </td>
                        <td><?= $rowpenduduk->tgl_lahir; ?> </td>
                        <td><?= $rowpenduduk->alamat; ?> </td>
                        <td><?= decimal($rowpenduduk->output, 2); ?>% (<?= gradehuruf($rowpenduduk->output); ?>) </td>
                        <td><?= bantuan($rowpenduduk->output); ?> </td>
                    </tr>
                <?php } ?>
            </tbody>
        </table>
    </div>
</div>