<?php
$judul = "Penetapan Fuzzy Inference System Pada Batuan Modal Tingkat Dusun/RW Berbasis Web Studi Kasus DPMDPPPA Kab. Bantaeng";
$judul_mini = "Fuzzy Inference System - Tsukamoto";
$lembaga = "Unknown";
$tagline = "Some Tag Line For Your Company";
?>