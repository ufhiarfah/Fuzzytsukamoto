<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Tsukamoto extends CI_Controller
{

    function __construct()
    {
        parent::__construct();
        $folder = ($this->session->userdata('level') == "superadmin") ? "admin" : $this->session->userdata('level');
        if (strtolower($folder) != "pendamping") {
            $this->session->set_flashdata('pesan', 'Anda Belum Login');
            redirect(site_url('home/login'));
            exit;
        }
        $this->load->helper('url');
    }

    public function index()
    {
        $this->load->model('model_variabel');
        $data['tabelvariabel'] = $this->model_variabel->getdata();
        $this->load->model('model_himpunan');
        $data['tabelhimpunan'] = $this->model_himpunan->getdata();
        $this->load->model('model_aturan');
        $data['tabelaturan'] = $this->model_aturan->getdata();
        $data['content'] = 'view_tsukamoto';
        $data['title'] = 'Input Data Penduduk';
        $data['status_variabel'] = ['input', 'output'];
        $data['status_himpunan'] = ['bahu kiri', 'bahu kanan'];
        $this->load->view('pendamping/template_pendamping', $data);
    }

    public function save()
    {
        $id_penduduk = uniqid();
        $data = array(
            'id_penduduk' => $id_penduduk,
            'nik' => $this->input->post('nik'),
            'nama_lengkap' => $this->input->post('nama_lengkap'),
            'jenis_kelamin' => $this->input->post('jenis_kelamin'),
            'tempat_lahir' => $this->input->post('tempat_lahir'),
            'tgl_lahir' => $this->input->post('tgl_lahir'),
            'alamat' => $this->input->post('alamat'),
            'variabel' => $this->input->post('variabel'),
            'output' => $this->input->post('output'),
            'pendamping' => $this->session->userdata('username'),

        );

        $this->load->model('model_penduduk');
        $this->model_penduduk->insertdata($data);
        $this->session->set_flashdata('message', '
				<div class="alert alert-success" role="alert">
					Data Berhasil diinput
				</div>
				');
        redirect(site_url('pendamping/penduduk'));
    }
}
