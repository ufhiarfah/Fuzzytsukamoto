<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Variabel extends CI_Controller
{

	function __construct()
	{
		parent::__construct();
        $folder = ($this->session->userdata('level') == "superadmin") ? "admin" : $this->session->userdata('level');
        if (strtolower($folder) != "admin") {
            $this->session->set_flashdata('pesan', 'Anda Belum Login');
            redirect(site_url('home/login'));
            exit;
        }
		$this->load->helper('url');
	}

	public function index()
    {
        $this->load->model('model_variabel');
        $data['tabelvariabel'] = $this->model_variabel->getdata();
        $this->load->model('model_himpunan');
        $data['tabelhimpunan'] = $this->model_himpunan->getdata();
		$data['content'] = 'view_variabel';
		$data['title'] = 'Data Variabel';
        $data['status_variabel'] = ['input', 'output'];
		$this->load->view('admin/template_admin', $data);
    }

    public function add()
    {
        $data['content'] = 'view_add_variabel';
        $data['title'] = 'Tambah Data Variabel';
        $data['status_variabel'] = ['input', 'output'];
        $this->load->view('admin/template_admin', $data);
    }

    public function detail()
    {
        $id = $this->uri->segment(4);
        $this->load->model('model_variabel');
        $data['rowvariabel'] = $this->model_variabel->selectdata($id);
        $this->load->model('model_himpunan');
        $data['tabelhimpunan'] = $this->model_himpunan->getdataby(['id_variabel' => $id]);
        $data['content'] = 'view_detail_variabel';
        $data['title'] = 'Deetail Variabel';
        $data['status_variabel'] = ['input', 'output'];
        $data['status_himpunan'] = ['bahu kiri', 'bahu kanan'];
        $this->load->view('admin/template_admin', $data);
    }

	public function save()
	{
        $id_variabel = uniqid();
		$data = array(
            'id_variabel' => $id_variabel,
            'nama_variabel' => $this->input->post('nama_variabel'),
            'satuan_variabel' => $this->input->post('satuan_variabel'),
            'status_variabel' => $this->input->post('status_variabel'),
            'keterangan1' => $this->input->post('keterangan1'),
            'keterangan2' => $this->input->post('keterangan2'),
		);

		$this->load->model('model_variabel');
		$this->model_variabel->insertdata($data);
		$this->session->set_flashdata('message', '
				<div class="alert alert-success" role="alert">
					Data Berhasil diinput
				</div>
				');
		redirect(site_url('admin/variabel/detail/'. $id_variabel));
	}

	public function update()
    {
        $id_variabel = $this->input->post('id_variabel');
        $data = array(
            'nama_variabel' => $this->input->post('nama_variabel'),
            'satuan_variabel' => $this->input->post('satuan_variabel'),
            'status_variabel' => $this->input->post('status_variabel'),
            'keterangan1' => $this->input->post('keterangan1'),
            'keterangan2' => $this->input->post('keterangan2'),
        );

        $this->load->model('model_variabel');
        $this->model_variabel->updatedata($data, $id_variabel);
        $this->session->set_flashdata('message', '
				<div class="alert alert-success" role="alert">
					Data Berhasil diubah
				</div>
				');
        redirect(site_url('admin/variabel/detail/' . $id_variabel));
	}

	public function delete()
	{
		$id = $this->uri->segment(4);
		$this->load->model('model_variabel');
        $this->load->model('model_himpunan');
        $this->model_variabel->deletedata($id);
        $this->model_himpunan->deletedataby(['id_himpunan'=>$id]);
        $this->session->set_flashdata('message', '
				<div class="alert alert-success" role="alert">
					Data Berhasil dihapus
				</div>
        ');
        redirect(site_url('admin/variabel'));
    }

    public function savehimpunan()
    {
        $id_variabel = $this->input->post('id_variabel');
        $data = array(
            'id_himpunan' => uniqid(),
            'id_variabel' => $id_variabel,
            'nama_himpunan' => $this->input->post('nama_himpunan'),
            'batas_bawah' => $this->input->post('batas_bawah'),
            'batas_atas' => $this->input->post('batas_atas'),
            'status_himpunan' => $this->input->post('status_himpunan'),
        );

        $this->load->model('model_himpunan');
        $this->model_himpunan->insertdata($data);
        $this->session->set_flashdata('message', '
				<div class="alert alert-success" role="alert">
					Data Berhasil diinput
				</div>
				');
        redirect(site_url('admin/variabel/detail/'. $id_variabel));
    }

    public function updatehimpunan()
    {
        $id_himpunan = $this->input->post('id_himpunan');
        $id_variabel = $this->input->post('id_variabel');
        $data = array(
            'id_variabel' => $this->input->post('id_variabel'),
            'nama_himpunan' => $this->input->post('nama_himpunan'),
            'batas_bawah' => $this->input->post('batas_bawah'),
            'batas_atas' => $this->input->post('batas_atas'),
            'status_himpunan' => $this->input->post('status_himpunan'),
        );

        $this->load->model('model_himpunan');
        $this->model_himpunan->updatedata($data, $id_himpunan);
        $this->session->set_flashdata('message', '
				<div class="alert alert-success" role="alert">
					Data Berhasil diinput
				</div>
				');
        redirect(site_url('admin/variabel/detail/' . $id_variabel));
    }

    public function deletehimpunan()
    {
        $id_himpunan = $this->uri->segment(4);
        $id_variabel = $this->uri->segment(5);
        $this->load->model('model_himpunan');
        $this->model_himpunan->deletedata($id_himpunan);
        $this->session->set_flashdata('message', '
				<div class="alert alert-success" role="alert">
					Data Berhasil dihapus
				</div>
        ');
        redirect(site_url('admin/variabel/detail/' . $id_variabel));
    }
}
