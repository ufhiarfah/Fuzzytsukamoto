<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Aturan extends CI_Controller
{

	function __construct()
	{
		parent::__construct();
        $folder = ($this->session->userdata('level') == "superadmin") ? "admin" : $this->session->userdata('level');
        if (strtolower($folder) != "admin") {
            $this->session->set_flashdata('pesan', 'Anda Belum Login');
            redirect(site_url('home/login'));
            exit;
        }
		$this->load->helper('url');
	}

	public function index()
	{
        $this->load->model('model_aturan');
        $data['tabelaturangroupby'] = $this->model_aturan->getdatagroupby('nomor');
        $data['tabelaturan'] = $this->model_aturan->getdata();
        $this->load->model('model_variabel');
        $data['tabelvariabel'] = $this->model_variabel->getdata();
        $this->load->model('model_himpunan');
        $data['tabelhimpunan'] = $this->model_himpunan->getdata();
		$data['content'] = 'view_aturan';
		$data['title'] = 'Data Aturan';
		$this->load->view('admin/template_admin', $data);
    }

	public function save()
    {
        $this->load->model('model_aturan');
        $nomor = uniqid();
        $id_variabel = $this->input->post('id_variabel');
        $id_himpunan = $this->input->post('id_himpunan');
        $index = 0;
        foreach ($id_variabel as $item) {
            $data = array(
                'id_aturan' => uniqid(),
                'nomor' => $nomor,
                'id_variabel' => $item,
                'id_himpunan' => $id_himpunan[$index],
            );
            $this->model_aturan->insertdata($data);
            $index++;
        }
		$this->session->set_flashdata('message', '
				<div class="alert alert-success" role="alert">
					Data Berhasil diinput
				</div>
				');
		redirect(site_url('admin/aturan'));
	}

	public function delete()
	{
		$id = $this->uri->segment(4);
		$this->load->model('model_aturan');
        $this->model_aturan->deletedataby(['nomor' => $id]);
        $this->session->set_flashdata('message', '
				<div class="alert alert-success" role="alert">
					Data Berhasil dihapus
				</div>
				');
        redirect(site_url('admin/aturan'));
	}
}
