<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Proposal extends CI_Controller
{

	function __construct()
	{
		parent::__construct();
        $folder = ($this->session->userdata('level') == "superadmin") ? "admin" : $this->session->userdata('level');
        if (strtolower($folder) != "admin") {
            $this->session->set_flashdata('pesan', 'Anda Belum Login');
            redirect(site_url('home/login'));
            exit;
        }
		$this->load->helper('url');
	}

	public function index()
    {
        $alamat = $_GET['alamat'];
        $hasil_prediksi = $_GET['hasil_prediksi'];
        $this->load->model('model_proposal');
        $data['tabelproposal'] = $this->model_proposal->getdata();
		$data['content'] = 'view_proposal';
		$data['title'] = 'Data Proposal';
		$this->load->view('admin/template_admin', $data);
    }

	public function cetak()
    {
        $this->load->model('model_proposal');
        $data['tabelproposal'] = $this->model_proposal->getdata();
		$data['content'] = 'view_proposal_cetak';
		$data['title'] = 'Data Proposal';
		$this->load->view('admin/template_cetak', $data);
    }

    public function add()
    {
        $data['content'] = 'view_add_proposal';
        $data['title'] = 'Tambah Data Proposal';
        $data['status_proposal'] = ['input', 'output'];
        $this->load->view('admin/template_admin', $data);
    }

    public function save()
    {
        $this->load->model('model_proposal');
        $id_proposal = uniqid();
        $data = array(
            'id_proposal' => $id_proposal,
            'nik' => $this->input->post('nik'),
            'nama_lengkap' => $this->input->post('nama_lengkap'),
            'jenis_kelamin' => $this->input->post('jenis_kelamin'),
            'tempat_lahir' => $this->input->post('tempat_lahir'),
            'tgl_lahir' => $this->input->post('tgl_lahir'),
            'alamat' => $this->input->post('alamat'),
            'nama_usaha' => $this->input->post('nama_usaha'),
            'deskripsi_usaha' => $this->input->post('deskripsi_usaha'),
            'proposal_usaha' => $this->model_proposal->uploadfile(),
            'variabel' => $this->input->post('variabel'),
            'output' => $this->input->post('output'),
        );

        $this->model_proposal->insertdata($data);
        $this->session->set_flashdata('message', '
				<div class="alert alert-success" role="alert">
					Data Berhasil diinput
				</div>
				');
        redirect(site_url('admin/proposal'));
    }

	public function update()
    {
        $id_proposal = $this->input->post('id_proposal');
        $data = array(
            'nama_proposal' => $this->input->post('nama_proposal'),
            'satuan_proposal' => $this->input->post('satuan_proposal'),
            'status_proposal' => $this->input->post('status_proposal'),
        );

        $this->load->model('model_proposal');
        $this->model_proposal->updatedata($data, $id_proposal);
        $this->session->set_flashdata('message', '
				<div class="alert alert-success" role="alert">
					Data Berhasil diubah
				</div>
				');
        redirect(site_url('admin/proposal/detail/' . $id_proposal));
	}

	public function delete()
	{
		$id = $this->uri->segment(4);
		$this->load->model('model_proposal');
        $this->model_proposal->deletedata($id);
        $this->session->set_flashdata('message', '
				<div class="alert alert-success" role="alert">
					Data Berhasil dihapus
				</div>
        ');
        redirect(site_url('admin/proposal'));
    }
}
