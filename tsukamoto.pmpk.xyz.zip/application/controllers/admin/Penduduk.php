<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Penduduk extends CI_Controller
{

	function __construct()
	{
		parent::__construct();
        $folder = ($this->session->userdata('level') == "superadmin") ? "admin" : $this->session->userdata('level');
        if (strtolower($folder) != "admin") {
            $this->session->set_flashdata('pesan', 'Anda Belum Login');
            redirect(site_url('home/login'));
            exit;
        }
		$this->load->helper('url');
	}

	public function index()
    {
        $alamat = $_GET['alamat'];
        $hasil_prediksi = $_GET['hasil_prediksi'];
        $this->load->model('model_penduduk');
        $data['tabelpenduduk'] = $this->model_penduduk->getdata();
		$data['content'] = 'view_penduduk';
		$data['title'] = 'Data Penduduk';
		$this->load->view('admin/template_admin', $data);
    }

	public function cetak()
    {
        $this->load->model('model_penduduk');
        $data['tabelpenduduk'] = $this->model_penduduk->getdata();
		$data['content'] = 'view_penduduk_cetak';
		$data['title'] = 'Data Penduduk';
		$this->load->view('admin/template_cetak', $data);
    }

    public function add()
    {
        $data['content'] = 'view_add_penduduk';
        $data['title'] = 'Tambah Data Penduduk';
        $data['status_penduduk'] = ['input', 'output'];
        $this->load->view('admin/template_admin', $data);
    }

    public function save()
    {
        $this->load->model('model_penduduk');
        $id_penduduk = uniqid();
        $data = array(
            'id_penduduk' => $id_penduduk,
            'nik' => $this->input->post('nik'),
            'nama_lengkap' => $this->input->post('nama_lengkap'),
            'jenis_kelamin' => $this->input->post('jenis_kelamin'),
            'tempat_lahir' => $this->input->post('tempat_lahir'),
            'tgl_lahir' => $this->input->post('tgl_lahir'),
            'alamat' => $this->input->post('alamat'),
            'nama_usaha' => $this->input->post('nama_usaha'),
            'deskripsi_usaha' => $this->input->post('deskripsi_usaha'),
            'proposal_usaha' => $this->model_penduduk->uploadfile(),
            'variabel' => $this->input->post('variabel'),
            'output' => $this->input->post('output'),
        );

        $this->model_penduduk->insertdata($data);
        $this->session->set_flashdata('message', '
				<div class="alert alert-success" role="alert">
					Data Berhasil diinput
				</div>
				');
        redirect(site_url('admin/penduduk'));
    }

	public function update()
    {
        $id_penduduk = $this->input->post('id_penduduk');
        $data = array(
            'nama_penduduk' => $this->input->post('nama_penduduk'),
            'satuan_penduduk' => $this->input->post('satuan_penduduk'),
            'status_penduduk' => $this->input->post('status_penduduk'),
        );

        $this->load->model('model_penduduk');
        $this->model_penduduk->updatedata($data, $id_penduduk);
        $this->session->set_flashdata('message', '
				<div class="alert alert-success" role="alert">
					Data Berhasil diubah
				</div>
				');
        redirect(site_url('admin/penduduk/detail/' . $id_penduduk));
	}

	public function delete()
	{
		$id = $this->uri->segment(4);
		$this->load->model('model_penduduk');
        $this->model_penduduk->deletedata($id);
        $this->session->set_flashdata('message', '
				<div class="alert alert-success" role="alert">
					Data Berhasil dihapus
				</div>
        ');
        redirect(site_url('admin/penduduk'));
    }
}
