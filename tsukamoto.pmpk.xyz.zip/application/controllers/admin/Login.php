<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Unit extends CI_Controller
{

	function __construct()
	{
		parent::__construct();
        $folder = ($this->session->userdata('level') == "superadmin") ? "admin" : $this->session->userdata('level');
        if (strtolower($folder) != "admin") {
            $this->session->set_flashdata('pesan', 'Anda Belum Login');
            redirect(site_url('home/login'));
            exit;
        }
		$this->load->helper('url');
	}

	public function index()
	{
        $this->load->model('model_unit');
        $data['tabelunit'] = $this->model_unit->getdata();
        $this->load->model('model_login');
        $data['tabellogin'] = $this->model_login->getdata();
		$data['content'] = 'view_unit';
		$data['title'] = 'Data Unit Entry';
		$this->load->view('admin/template_admin', $data);
	}

	public function detail()
	{
		$id = $this->uri->segment(4);
		$this->load->model('model_unit');
		$data['rowunit'] = $this->model_unit->selectdata($id);
        $this->load->model('model_login');
        $data['tabellogin'] = $this->model_login->getdata();
		$data['content'] = 'view_detail_unit';
		$data['title'] = 'Detail Unit Entry';
		$this->load->view('admin/template_admin', $data);
	}

	public function add()
    {
        $this->load->model('model_login');
        $data['tabellogin'] = $this->model_login->getdataby(['level' => 'sa']);
        $data['arr_tahapan'] = [
            'Waiting List',
            'Estimasi',
            'Menunggu SPK',
            'Production',
        ];
        $data['arr_vendor_rekomendasi'] = [
            'TEAM 1',
            'TEAM 2',
            'TEAM 3',
        ];
        $data['arr_cabang'] = [
            'PAREPARE',
            'SATELIT 1',
            'SATELIT 2',
            'SATELIT 3',
        ];
        $data['arr_tipe'] = [
            'Asuransi',
            'Umum',
        ];
        $data['arr_kerusakan'] = [
            'Ringan',
            'Sedang',
            'Berat',
        ];
		$data['content'] = 'view_add_unit';
		$data['title'] = 'Add Data Unit Entry';
		$this->load->view('admin/template_admin', $data);
	}

	public function save()
	{
		$user = $this->session->userdata('username');
		$data = array(
			'user' => $user,
            'uid_unit' => uniqid(),
            'service_advisor' => $this->input->post('service_advisor'),
            'tahapan' => $this->input->post('tahapan'),
            'vendor_rekomendasi' => $this->input->post('vendor_rekomendasi'),
            'cabang' => $this->input->post('cabang'),
            'nama_customer' => $this->input->post('nama_customer'),
            'nomor_polisi' => $this->input->post('nomor_polisi'),
            'merk' => $this->input->post('merk'),
            'model' => $this->input->post('model'),
            'warna' => $this->input->post('warna'),
            'jumlah_panel' => $this->input->post('jumlah_panel'),
            'estimasi_biaya' => $this->input->post('estimasi_biaya'),
            'tgl_penerimaan' => $this->input->post('tgl_penerimaan'),
            'janji_tgl_penyerahan' => $this->input->post('janji_tgl_penyerahan'),
            'tipe_customer' => $this->input->post('tipe_customer'),
            'jenis_kerusakan' => $this->input->post('jenis_kerusakan'),
		);

		$this->load->model('model_unit');
		$this->model_unit->insertdata($data);
		$this->session->set_flashdata('message', '
				<div class="alert alert-success" role="alert">
					Data Berhasil diinput
				</div>
				');
		redirect(site_url('admin/unit'));
	}

	public function edit()
	{
		$id = $this->uri->segment(4);
		$this->load->model('model_unit');
		$data['rowunit'] = $this->model_unit->selectdata($id);
        $this->load->model('model_login');
        $data['tabellogin'] = $this->model_login->getdataby(['level' => 'sa']);
        $data['arr_tahapan'] = [
            'Waiting List',
            'Estimasi',
            'Menunggu SPK',
            'Production',
        ];
        $data['arr_vendor_rekomendasi'] = [
            'TEAM 1',
            'TEAM 2',
            'TEAM 3',
        ];
        $data['arr_cabang'] = [
            'PAREPARE',
            'SATELIT 1',
            'SATELIT 2',
            'SATELIT 3',
        ];
        $data['arr_tipe'] = [
            'Asuransi',
            'Umum',
        ];
        $data['arr_kerusakan'] = [
            'Ringan',
            'Sedang',
            'Berat',
        ];
		$data['content'] = 'view_edit_unit';
		$data['title'] = 'Edit Unit Entry';
		$this->load->view('admin/template_admin', $data);
	}

	public function update()
    {
        $id = $this->uri->segment(4);
        $user = $this->session->userdata('username');
        $data = array(
            'user' => $user,
            'service_advisor' => $this->input->post('service_advisor'),
            'tahapan' => $this->input->post('tahapan'),
            'vendor_rekomendasi' => $this->input->post('vendor_rekomendasi'),
            'cabang' => $this->input->post('cabang'),
            'nama_customer' => $this->input->post('nama_customer'),
            'nomor_polisi' => $this->input->post('nomor_polisi'),
            'merk' => $this->input->post('merk'),
            'model' => $this->input->post('model'),
            'warna' => $this->input->post('warna'),
            'jumlah_panel' => $this->input->post('jumlah_panel'),
            'estimasi_biaya' => $this->input->post('estimasi_biaya'),
            'tgl_penerimaan' => $this->input->post('tgl_penerimaan'),
            'janji_tgl_penyerahan' => $this->input->post('janji_tgl_penyerahan'),
            'tipe_customer' => $this->input->post('tipe_customer'),
            'jenis_kerusakan' => $this->input->post('jenis_kerusakan'),
        );

        $this->load->model('model_unit');
        $this->model_unit->updatedata($data, $id);
        $this->session->set_flashdata('message', '
				<div class="alert alert-success" role="alert">
					Data Berhasil diubah
				</div>
				');
        redirect(site_url('admin/unit'));
	}

	public function delete()
	{
		$id = $this->uri->segment(4);
		$this->load->model('model_unit');
		$this->model_unit->deletedata($id);

		redirect(site_url('admin/unit'));
	}

	public function excel()
	{
		$this->load->model('model_mitra');
		// $this->model_mitra->deleteall();
		if (isset($_FILES["file"]["name"])) {
			$file_tmp = $_FILES['file']['tmp_name'];
			$file_name = $_FILES['file']['name'];
			$file_size = $_FILES['file']['size'];
			$file_type = $_FILES['file']['type'];
			// move_uploaded_file($file_tmp,"uploads/".$file_name); // simpan filenya di folder uploads
			$object = PHPExcel_IOFactory::load($file_tmp);
			foreach ($object->getWorksheetIterator() as $worksheet) {
				$highestRow = $worksheet->getHighestRow();
				$highestColumn = $worksheet->getHighestColumn();
                $count = 0;
				for ($row = 3; $row <= $highestRow; $row++) {
                    $nm_mitra = $worksheet->getCellByColumnAndRow(1, $row)->getValue();
                    $bidang = $worksheet->getCellByColumnAndRow(2, $row)->getValue();
                    $alamat = $worksheet->getCellByColumnAndRow(3, $row)->getValue();
                    $no_telp = $worksheet->getCellByColumnAndRow(4, $row)->getValue();
                    $email = $worksheet->getCellByColumnAndRow(5, $row)->getValue();
                    $nm_pic = $worksheet->getCellByColumnAndRow(6, $row)->getValue();
                    $jabatan_pic = $worksheet->getCellByColumnAndRow(7, $row)->getValue();
                    $alamat_pic = $worksheet->getCellByColumnAndRow(8, $row)->getValue();
                    $no_telp_pic = $worksheet->getCellByColumnAndRow(9, $row)->getValue();
                    $email_pic = $worksheet->getCellByColumnAndRow(10, $row)->getValue();
                    $ket = $worksheet->getCellByColumnAndRow(11, $row)->getValue();
                    $user = $worksheet->getCellByColumnAndRow(12, $row)->getValue();
                    $unit = get_unit($user);
					if ($nm_mitra != "" || $bidang != "" || $alamat != "" || $no_telp != "" || $email != "" || $nm_pic != "" || $jabatan_pic != "" || $alamat_pic !="" || $no_telp_pic !="" || $email_pic !="" || $ket !="" || $user !="" || $unit != "") {
                        $array = array(
                            'nm_mitra' => $nm_mitra,
                            'bidang' => $bidang,
                            'alamat' => $alamat,
                            'no_telp' => $no_telp,
                            'email' => $email,
                            'nm_pic' => $nm_pic,
                            'jabatan_pic' => $jabatan_pic,
                            'alamat_pic' => $alamat_pic,
                            'no_telp_pic' => $no_telp_pic,
                            'email_pic' => $email_pic,
                            'ket' => $ket,
                            'user' => $user,
                            'unit_krj' => $unit,
                        );
						$this->model_mitra->insertdata($array);
                        $count++;
					}
				}
			}
			$message = array(
				'message' => '<div class="alert alert-success">Import file excel berhasil, ' . $count . ' disimpan di database</div>',
			);
			$this->session->set_flashdata($message);
			redirect(site_url('admin/mitra'));
		} else {
			$message = array(
				'message' => '<div class="alert alert-danger">Import file gagal, coba lagi</div>',
			);
			$this->session->set_flashdata($message);
			redirect(site_url('admin/mitra'));
		}
	}
}
