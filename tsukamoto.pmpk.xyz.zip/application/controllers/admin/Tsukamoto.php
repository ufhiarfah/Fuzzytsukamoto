<?php


defined('BASEPATH') or exit('No direct script access allowed');

class Tsukamoto extends CI_Controller
{
	private $alternatives;
	private $criteria;
	private $weights;
	private $values;
	function __construct()
	{
		parent::__construct();
		$folder = ($this->session->userdata('level') == "superadmin") ? "admin" : $this->session->userdata('level');
		if (strtolower($folder) != "admin") {
			$this->session->set_flashdata('pesan', 'Anda Belum Login');
			redirect(site_url('home/login'));
			exit;
		}
		$this->load->helper('url');
	}

	public function index()
	{
		$this->load->model('model_variabel');
		$data['tabelvariabel'] = $this->model_variabel->getdata();
		$this->load->model('model_himpunan');
		$data['tabelhimpunan'] = $this->model_himpunan->getdata();
		$this->load->model('model_aturan');
		$data['tabelaturan'] = $this->model_aturan->getdata();
		$data['content'] = 'view_tsukamoto';
		$data['title'] = 'Input Data Proposal';
		$data['status_variabel'] = ['input', 'output'];
		$data['status_himpunan'] = ['bahu kiri', 'bahu kanan'];
		$this->load->view('admin/template_admin', $data);
	}

	function submit($nilai)
	{
		$kip_kuliah = "KIP KULIAH";
		$pkh = "PKH";
		$kip = "KIP";
		$bpnt = "BPNT";
		$kis = "KIS";
		$z = 0;
		return $z;
	}

	public function save()
	{
		$id_proposal = uniqid();

		$data_variabel = explode(',', $this->input->post('data_variabel'));
		$output = $this->input->post('output');

        $this->load->model('model_proposal');

		$data = array(
			'id_proposal' => $id_proposal,
			'nik' => $this->input->post('nik'),
			'nama_lengkap' => $this->input->post('nama_lengkap'),
			'jenis_kelamin' => $this->input->post('jenis_kelamin'),
			'tempat_lahir' => $this->input->post('tempat_lahir'),
			'tgl_lahir' => $this->input->post('tgl_lahir'),
			'alamat' => $this->input->post('alamat'),
            'nama_usaha' => $this->input->post('nama_usaha'),
            'deskripsi_usaha' => $this->input->post('deskripsi_usaha'),
            'proposal_usaha' => $this->model_proposal->uploadfile(),
			'variabel' => $this->input->post('variabel'),
			'output' => $output,
			'pendamping' => $this->session->userdata('username'),
			'bantuan' => '',
		);

		$this->model_proposal->insertdata($data);
		$this->session->set_flashdata('message', '
				<div class="alert alert-success" role="alert">
					Data Berhasil diinput
				</div>
				');
		redirect(site_url('admin/proposal'));
	}
}
