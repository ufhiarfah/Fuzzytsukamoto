<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Model_aturan extends CI_Model
{

    public function getdata()
    {
        return $this->db->get('aturan')->result();
    }

    public function getdataby($array)
    {
        $this->db->where($array);
        return $this->db->get('aturan')->result();
    }

    public function getdatagroupby($column)
    {
        $this->db->order_by('timestamp', 'desc');
        $this->db->group_by($column);
        return $this->db->get('aturan')->result();
    }

    public function countdata()
    {
        
        return $this->db->get('aturan')->num_rows();
    }

    public function countdataby($array)
    {
        
        $this->db->where($array);
        return $this->db->get('aturan')->num_rows();
    }
    public function selectdata($id)
    {
        $this->db->where('id_aturan', $id);
        return $this->db->get('aturan')->row();
    }

    public function selectdataby($array)
    {
        $this->db->where($array);
        return $this->db->get('aturan')->row();
    }

    public function insertdata($data)
    {
        $this->db->insert('aturan', $data);
        $this->db->insert_id();
    }

    public function updatedata($data, $id)
    {
        $this->db->where('id_aturan', $id);
        $this->db->update('aturan', $data);
    }

    public function updatedataby($data, $array)
    {
        $this->db->where($array);
        $this->db->update('aturan', $data);
    }

    public function deletedata($id)
    {
        $this->db->where('id_aturan', $id);
        $this->db->delete('aturan');
    }

    public function deletedataby($array)
    {
        $this->db->where($array);
        $this->db->delete('aturan');
    }
}
