<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Model_variabel extends CI_Model
{

    public function getdata()
    {
        $this->db->order_by('status_variabel', 'asc'); 
        return $this->db->get('variabel')->result();
    }

    public function getdataby($array)
    {
        $this->db->order_by('status_variabel', 'desc');
        $this->db->where($array);
        return $this->db->get('variabel')->result();
    }

    public function countdata()
    {
        
        return $this->db->get('variabel')->num_rows();
    }

    public function countdataby($array)
    {
        
        $this->db->where($array);
        return $this->db->get('variabel')->num_rows();
    }
    public function selectdata($id)
    {
        $this->db->where('id_variabel', $id);
        return $this->db->get('variabel')->row();
    }

    public function selectdataby($array)
    {
        $this->db->where($array);
        return $this->db->get('variabel')->row();
    }

    public function insertdata($data)
    {
        $this->db->insert('variabel', $data);
        $this->db->insert_id();
    }

    public function updatedata($data, $id)
    {
        $this->db->where('id_variabel', $id);
        $this->db->update('variabel', $data);
    }

    public function updatedataby($data, $array)
    {
        $this->db->where($array);
        $this->db->update('variabel', $data);
    }

    public function deletedata($id)
    {
        $this->db->where('id_variabel', $id);
        $this->db->delete('variabel');
    }

    public function deletedataby($array)
    {
        $this->db->where($array);
        $this->db->delete('variabel');
    }
}
