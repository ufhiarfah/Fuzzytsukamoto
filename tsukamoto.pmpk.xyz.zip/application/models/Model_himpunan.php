<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Model_himpunan extends CI_Model
{

    public function getdata()
    {
        return $this->db->get('himpunan')->result();
    }

    public function getdataby($array)
    {
        $this->db->where($array);
        return $this->db->get('himpunan')->result();
    }

    public function countdata()
    {
        
        return $this->db->get('himpunan')->num_rows();
    }

    public function countdataby($array)
    {
        $this->db->where($array);
        return $this->db->get('himpunan')->num_rows();
    }
    public function selectdata($id)
    {
        $this->db->where('id_himpunan', $id);
        return $this->db->get('himpunan')->row();
    }

    public function selectdataby($array)
    {
        $this->db->where($array);
        return $this->db->get('himpunan')->row();
    }

    public function insertdata($data)
    {
        $this->db->insert('himpunan', $data);
        $this->db->insert_id();
    }

    public function updatedata($data, $id)
    {
        $this->db->where('id_himpunan', $id);
        $this->db->update('himpunan', $data);
    }

    public function updatedataby($data, $array)
    {
        $this->db->where($array);
        $this->db->update('himpunan', $data);
    }

    public function deletedata($id)
    {
        $this->db->where('id_himpunan', $id);
        $this->db->delete('himpunan');
    }

    public function deletedataby($array)
    {
        $this->db->where($array);
        $this->db->delete('himpunan');
    }
}
