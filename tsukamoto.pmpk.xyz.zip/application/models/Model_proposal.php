<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Model_proposal extends CI_Model
{

    public function getdata()
    {
        return $this->db->get('proposal')->result();
    }

    public function getdataby($array)
    {
        $this->db->where($array);
        return $this->db->get('proposal')->result();
    }

    public function countdata()
    {
        
        return $this->db->get('proposal')->num_rows();
    }

    public function countdataby($array)
    {
        
        $this->db->where($array);
        return $this->db->get('proposal')->num_rows();
    }
    public function selectdata($id)
    {
        $this->db->where('id_proposal', $id);
        return $this->db->get('proposal')->row();
    }

    public function selectdataby($array)
    {
        $this->db->where($array);
        return $this->db->get('proposal')->row();
    }

    public function insertdata($data)
    {
        $this->db->insert('proposal', $data);
        $this->db->insert_id();
    }

    public function updatedata($data, $id)
    {
        $this->db->where('id_proposal', $id);
        $this->db->update('proposal', $data);
    }

    public function updatedataby($data, $array)
    {
        $this->db->where($array);
        $this->db->update('proposal', $data);
    }

    public function deletedata($id)
    {
        $this->db->where('id_proposal', $id);
        $this->db->delete('proposal');
    }

    public function deletedataby($array)
    {
        $this->db->where($array);
        $this->db->delete('proposal');
    }

    public function uploadfile()
    {
        $config['upload_path']          = 'assets/upload/proposal/';
        $config['allowed_types']        = '*';
        $config['file_name']            = uniqid();
        $config['overwrite']            = true;
        // $config['max_size']             = 1024; // 1MB
        // $config['max_width']            = 1024;
        // $config['max_height']           = 768;

        $this->load->library('upload', $config);

        if ($this->upload->do_upload('proposal_usaha')) {
            return $this->upload->data("file_name");
        }

        return "default.jpg";
    }

    public function deletefile($id)
    {
        $proposal = $this->selectdata($id);
        if ($proposal->proposal_usaha != "default.jpg") {
            $filename = explode(".", $proposal->proposal_usaha)[0];
            return array_map('unlink', glob(FCPATH . "assets/upload/proposal/$filename.*"));
        }
    }
}
