<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Model_proposal extends CI_Model
{

    public function getdata()
    {
        return $this->db->get('proposal')->result();
    }

    public function getdataby($array)
    {
        $this->db->where($array);
        return $this->db->get('proposal')->result();
    }

    public function countdata()
    {
        
        return $this->db->get('proposal')->num_rows();
    }

    public function countdataby($array)
    {
        
        $this->db->where($array);
        return $this->db->get('proposal')->num_rows();
    }
    public function selectdata($id)
    {
        $this->db->where('id_proposal', $id);
        return $this->db->get('proposal')->row();
    }

    public function selectdataby($array)
    {
        $this->db->where($array);
        return $this->db->get('proposal')->row();
    }

    public function insertdata($data)
    {
        $this->db->insert('proposal', $data);
        $this->db->insert_id();
    }

    public function updatedata($data, $id)
    {
        $this->db->where('id_proposal', $id);
        $this->db->update('proposal', $data);
    }

    public function updatedataby($data, $array)
    {
        $this->db->where($array);
        $this->db->update('proposal', $data);
    }

    public function deletedata($id)
    {
   