<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Model_program extends CI_Model
{

    public function getdata()
    {
        $this->db->order_by('timestamp', 'desc');
        $this->db->where('deleted', '0000-00-00 00:00:00');
        return $this->db->get('program')->result();
    }

    public function getdataby($array)
    {
        $this->db->order_by('timestamp', 'desc');
        $this->db->where('deleted', '0000-00-00 00:00:00');
        $this->db->where($array);
        return $this->db->get('program')->result();
    }

    public function countdata()
    {
        $this->db->where('deleted', '0000-00-00 00:00:00');
        return $this->db->get('program')->num_rows();
    }

    public function countdataby($array)
    {
        $this->db->where('deleted', '0000-00-00 00:00:00');
        $this->db->where($array);
        return $this->db->get('program')->num_rows();
    }
    public function selectdata($id)
    {
        $this->db->where('id_program', $id);
        return $this->db->get('program')->row();
    }

    public function selectdataby($array)
    {
        $this->db->where($array);
        return $this->db->get('program')->row();
    }

    public function insertdata($data)
    {
        $this->db->insert('program', $data);
        $this->db->insert_id();
    }

    public function updatedata($data, $id)
    {
        $this->db->where('id_program', $id);
        $this->db->update('program', $data);
    }

    public function updatedataby($data, $array)
    {
        $this->db->where($array);
        $this->db->update('program', $data);
    }

    public function deletedata($id)
    {
        $this->db->where('id_program', $id);
        $this->db->delete('program');
    }

    public function deletedataby($array)
    {
        $this->db->where($array);
        $this->db->delete('program');
    }
}
