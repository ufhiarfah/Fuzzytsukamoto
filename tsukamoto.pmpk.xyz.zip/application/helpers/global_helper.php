<?php

function gradehuruf($nilai) {
	if ($nilai == "") {
		$grade = "";
	} else if ($nilai >= 0 && $nilai <= 10) {
		$grade = 'Sangat Miskin';
	} else if ($nilai >= 10 && $nilai <= 20) {
		$grade = 'Miskin';
	} else if ($nilai >= 20 && $nilai <= 30) {
		$grade = 'Hampir Miskin';
	} else if ($nilai >= 30 && $nilai <= 40) {
		$grade = 'Rentan Miskin'; 
	} else if ($nilai >= 40 && $nilai <= 100) {
		$grade = 'Sangat Mampu';
	}
	return $grade;
}

function bantuan($nilai) {
	if ($nilai == "") {
		$grade = "KIP Kuliah";
	} else if ($nilai >= 0 && $nilai <= 10) {
		$grade = 'PKH, KIP, BPNT, DAN KIS';
	} else if ($nilai >= 10 && $nilai <= 20) {
		$grade = 'KIP, BPNT, KIS';
	} else if ($nilai >= 20 && $nilai <= 30) {
		$grade = 'BPNT, KIS';
	} else if ($nilai >= 30 && $nilai <= 40) {
		$grade = 'KIS'; 
	} else if ($nilai >= 40 && $nilai <= 100) {
		$grade = 'KIP KULIAH';
	}
	return $grade;
}

function reversegeocode($mapsapikey, $lat, $lng, $location_type) {
    $url = "https://maps.googleapis.com/maps/api/geocode/json?latlng=$lat,$lng&location_type=$location_type&result_type=street_address&key=$mapsapikey";
    $json = file_get_contents($url);
    $json = json_decode($json);
    return $json->plus_code->compound_code;
}

function kirim_email($address, $subjek, $pesan)
{
	$ci =& get_instance();
	$ci->load->library("phpmailer_library");
	$mail = $ci->phpmailer_library->load();
	$mail->isSMTP();
	$mail->SMTPSecure = 'ssl';
	$mail->Host = 'yayasanhadjikalla.co.id';
	$mail->SMTPAuth = true;
	$mail->Username = 'is@yayasanhadjikalla.co.id';
	$mail->Password = '{Mb28qeIo(mo';
	$mail->SMTPSecure = 'ssl';
	$mail->Port = 465;
	$mail->SetFrom("is@yayasanhadjikalla.co.id", "YHK-IS");
	$mail->Subject = $subjek;
	foreach ($address as $email => $nama) {
		$mail->AddAddress($email, $nama);
	}
	$mail->MsgHTML($pesan);
	if ($mail->Send()) {
		return "Email Terkirim";
	}
}

function rmspace($string) {
	return preg_replace('/\s+/', '', $string);
}

function format_tanggal($waktu)
{
	$tanggal = date('j', strtotime($waktu));
	$bulan_array = array(
		1 => 'Januari',
		2 => 'Februari',
		3 => 'Maret',
		4 => 'April',
		5 => 'Mei',
		6 => 'Juni',
		7 => 'Juli',
		8 => 'Agustus',
		9 => 'September',
		10 => 'Oktober',
		11 => 'November',
		12 => 'Desember',
	);
	$bl = date('n', strtotime($waktu));
	$bulan = $bulan_array[$bl];
	$tahun = date('Y', strtotime($waktu));
	return "$tanggal $bulan $tahun";
}

function format_hari_tanggal($waktu)
{
	$hari_array = array(
		'Minggu',
		'Senin',
		'Selasa',
		'Rabu',
		'Kamis',
		'Jumat',
		'Sabtu'
	);
	$hr = date('w', strtotime($waktu));
	$hari = $hari_array[$hr];
	$tanggal = date('j', strtotime($waktu));
	$bulan_array = array(
		1 => 'Januari',
		2 => 'Februari',
		3 => 'Maret',
		4 => 'April',
		5 => 'Mei',
		6 => 'Juni',
		7 => 'Juli',
		8 => 'Agustus',
		9 => 'September',
		10 => 'Oktober',
		11 => 'November',
		12 => 'Desember',
	);
	$bl = date('n', strtotime($waktu));
	$bulan = $bulan_array[$bl];
	$tahun = date('Y', strtotime($waktu));
	$jam = date('H:i:s', strtotime($waktu));

	//untuk menampilkan hari, tanggal bulan tahun jam
	//return "$hari, $tanggal $bulan $tahun $jam";

	//untuk menampilkan hari, tanggal bulan tahun
	return "$hari, $tanggal $bulan $tahun, $jam";
}

function getRomawi($bln) {
	switch ($bln) {
		case 1: return "I"; break;
		case 2: return "II"; break;
		case 3: return "III"; break;
		case 4: return "IV"; break;
		case 5: return "V"; break;
		case 6: return "VI"; break;
		case 7: return "VII"; break;
		case 8: return "VIII"; break;
		case 9: return "IX"; break;
		case 10: return "X"; break;
		case 11: return "XI"; break;
		case 12: return "XII"; break;
	}
}

function nopo()
{
	$bulan = date('n');
	$romawi = getRomawi($bulan);
	$tahun = date('Y');
	$nomor = "/SMI/PO/" . $romawi . "/" . $tahun;
	// membaca kode  terbesar dari penomoran yang ada didatabase berdasarkan tanggal
	$ci = &get_instance();
	$sql = "SELECT max(nomor_po) as maxKode FROM permintaan WHERE nomor_po LIKE '%/$tahun%'";
	$query = $ci->db->query($sql);
	$data = $query->row();

	$no = $data->maxKode;
	$noUrut = $no + 1;
	//Membuat Nomor dengan awalan depan 0 misalnya , 01,02 
	//Jika ingin 003 ,tinggal ganti %03
	$kode =  sprintf("%02s", $noUrut);
	return $kode . $nomor;
}

function noso()
{
	$bulan = date('n');
	$romawi = getRomawi($bulan);
	$tahun = date('Y');
	$nomor = "/SMI/SO/" . $romawi . "/" . $tahun;
	// membaca kode  terbesar dari penomoran yang ada didatabase berdasarkan tanggal
	$ci = &get_instance();
	$sql = "SELECT max(nomor_so) as maxKode FROM penjualan WHERE nomor_so LIKE '%/$tahun%'";
	$query = $ci->db->query($sql);
	$data = $query->row();

	$no = $data->maxKode;
	$noUrut = $no + 1;
	//Membuat Nomor dengan awalan depan 0 misalnya , 01,02 
	//Jika ingin 003 ,tinggal ganti %03
	$kode =  sprintf("%02s", $noUrut);
	return $kode . $nomor;
}

function nointernalmemo()
{
    error_reporting(0);
    $bulan = date('n');
    $romawi = getRomawi($bulan);
    $tahun = date('Y');
    $nomor = "/YHK/IOM-Sekretariat/" . $romawi . "/" . $tahun;
    // membaca kode  terbesar dari penomoran yang ada didatabase berdasarkan tanggal
    $ci = &get_instance();
    $sql = "SELECT max(no_surat) as maxKode FROM tb_internal_memo WHERE no_surat LIKE '%/$tahun%'";
    $query = $ci->db->query($sql);
    $data = $query->row();

    $no = $data->maxKode;
    $noUrut = $no + 1;
    //Membuat Nomor dengan awalan depan 0 misalnya , 01,02 
    //Jika ingin 003 ,tinggal ganti %03
    $kode =  sprintf("%02s", $noUrut);
    return $kode . $nomor;
}

function nosppd()
{
    error_reporting(0);
    $bulan = date('n');
    $romawi = getRomawi($bulan);
    $tahun = date('Y');
    $nomor = "/SPJ/YHK/" . $romawi . "/" . $tahun;
    // membaca kode  terbesar dari penomoran yang ada didatabase berdasarkan tanggal
    $ci = &get_instance();
    $sql = "SELECT max(no_sppd) as maxKode FROM tb_sppd WHERE no_sppd LIKE '%/$tahun%'";
    $query = $ci->db->query($sql);
    $data = $query->row();

    $no = $data->maxKode;
    $noUrut = $no + 1;
    //Membuat Nomor dengan awalan depan 0 misalnya , 01,02 
    //Jika ingin 003 ,tinggal ganti %03
    $kode =  sprintf("%02s", $noUrut);
    return $kode . $nomor;
}

function nopelatihan() {
	error_reporting(0);
	$bulan = date('n');
	$romawi = getRomawi($bulan);
	$tahun = date ('Y');
	$nomor = "/PSDM/YHK/".$romawi."/".$tahun;
	// membaca kode  terbesar dari penomoran yang ada didatabase berdasarkan tanggal
	$ci =& get_instance();
	$sql = "SELECT max(no_pelatihan) as maxKode FROM tb_pelatihan WHERE no_pelatihan LIKE '%/$tahun%'";
	$query = $ci->db->query($sql);
	$data = $query->row();
    
	$no = $data->maxKode;
	$noUrut = $no + 1;
	//Membuat Nomor dengan awalan depan 0 misalnya , 01,02 
	//Jika ingin 003 ,tinggal ganti %03
	$kode =  sprintf("%02s", $noUrut);
	return $kode.$nomor;
}
function time_elapsed_string($datetime, $full = false)
{
	$now = new DateTime;
	$ago = new DateTime($datetime);
	$diff = $now->diff($ago);

	$diff->w = floor($diff->d / 7);
	$diff->d -= $diff->w * 7;

	$string = array(
		'y' => 'year',
		'm' => 'month',
		'w' => 'week',
		'd' => 'day',
		'h' => 'hour',
		'i' => 'minute',
		's' => 'second',
	);
	foreach ($string as $k => &$v) {
		if ($diff->$k) {
			$v = $diff->$k . ' ' . $v . ($diff->$k > 1 ? 's' : '');
		} else {
			unset($string[$k]);
		}
	}

	if (!$full) $string = array_slice($string, 0, 1);
	return $string ? implode(', ', $string) . ' ago' : 'just now';
}

function countDays($a, $b) {
	$start = new DateTime($a);
	$end = new DateTime($b);
	$end->modify('+1 day');
	$interval = $end->diff($start);
	$days = $interval->days;
	$period = new DatePeriod($start, new DateInterval('P1D'), $end);
	$holidays = array('2012-09-07');
	return $days; // 4
}

function countDaysWW($a, $b) {
	$start = new DateTime($a);
	$end = new DateTime($b);
	$end->modify('+1 day');
	$interval = $end->diff($start);
	$days = $interval->days;
	$period = new DatePeriod($start, new DateInterval('P1D'), $end);
	$holidays = array('2012-09-07');
	foreach($period as $dt) {
		$curr = $dt->format('D');
		if ($curr == 'Sat' || $curr == 'Sun') {
			$days--;
		} elseif (in_array($dt->format('Y-m-d'), $holidays)) {
			$days--;
		}
	}
	return $days; // 4
}

if(!function_exists('bulan'))
{
    function bulan($bulan)
    {
    Switch ($bulan){
        case 1 : $bulan="Januari";
            Break;
        case 2 : $bulan="Februari";
            Break;
        case 3 : $bulan="Maret";
            Break;
        case 4 : $bulan="April";
            Break;
        case 5 : $bulan="Mei";
            Break;
        case 6 : $bulan="Juni";
            Break;
        case 7 : $bulan="Juli";
            Break;
        case 8 : $bulan="Agustus";
            Break;
        case 9 : $bulan="September";
            Break;
        case 10 : $bulan="Oktober";
            Break;
        case 11 : $bulan="November";
            Break;
        case 12 : $bulan="Desember";
            Break;
        }
    return $bulan;
    }
}

function penyebut($nilai)
{
	$nilai = abs($nilai);
	$huruf = array("", "satu", "dua", "tiga", "empat", "lima", "enam", "tujuh", "delapan", "sembilan", "sepuluh", "sebelas");
	$temp = "";
	if ($nilai < 12) {
		$temp = " " . $huruf[$nilai];
	} else if ($nilai < 20) {
		$temp = penyebut($nilai - 10) . " belas";
	} else if ($nilai < 100) {
		$temp = penyebut($nilai / 10) . " puluh" . penyebut($nilai % 10);
	} else if ($nilai < 200) {
		$temp = " seratus" . penyebut($nilai - 100);
	} else if ($nilai < 1000) {
		$temp = penyebut($nilai / 100) . " ratus" . penyebut($nilai % 100);
	} else if ($nilai < 2000) {
		$temp = " seribu" . penyebut($nilai - 1000);
	} else if ($nilai < 1000000) {
		$temp = penyebut($nilai / 1000) . " ribu" . penyebut($nilai % 1000);
	} else if ($nilai < 1000000000) {
		$temp = penyebut($nilai / 1000000) . " juta" . penyebut($nilai % 1000000);
	} else if ($nilai < 1000000000000) {
		$temp = penyebut($nilai / 1000000000) . " milyar" . penyebut(fmod($nilai, 1000000000));
	} else if ($nilai < 1000000000000000) {
		$temp = penyebut($nilai / 1000000000000) . " trilyun" . penyebut(fmod($nilai, 1000000000000));
	}
	return $temp;
}

function terbilang($nilai)
{
	if ($nilai < 0) {
		$hasil = "minus " . trim(penyebut($nilai));
	} else {
		$hasil = trim(penyebut($nilai));
	}
	return $hasil;
}

if(!function_exists('decimal'))
{
    function decimal($val, $tail=2) 
    {
        return number_format($val, $tail);
    }
}

?>
