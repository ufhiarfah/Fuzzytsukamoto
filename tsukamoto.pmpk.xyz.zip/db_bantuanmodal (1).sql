-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Waktu pembuatan: 09 Feb 2024 pada 00.27
-- Versi server: 10.5.23-MariaDB-cll-lve
-- Versi PHP: 8.1.27

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `yayasa18_bantuanmodal`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `aturan`
--

CREATE TABLE `aturan` (
  `id_aturan` varchar(191) NOT NULL,
  `nomor` varchar(191) DEFAULT NULL,
  `id_variabel` varchar(191) DEFAULT NULL,
  `id_himpunan` varchar(191) DEFAULT NULL,
  `timestamp` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data untuk tabel `aturan`
--

INSERT INTO `aturan` (`id_aturan`, `nomor`, `id_variabel`, `id_himpunan`, `timestamp`) VALUES
('65bdf965bca85', '65bdf965bca3b', '65b5074eb165f', '65b507a9af843', '2024-02-03 15:29:25'),
('65bdf965bce95', '65bdf965bca3b', '65b507f3f1a11', '65b5080155bb3', '2024-02-03 15:29:25'),
('65bdf965bd19b', '65bdf965bca3b', '65b5083fdc670', '65b508ca9e9c1', '2024-02-03 15:29:25'),
('65bdf965bd4bb', '65bdf965bca3b', '65b508fd7bf13', '65b5091dc4aac', '2024-02-03 15:29:25'),
('65bdf965bd73d', '65bdf965bca3b', '65b509460a8dc', '65b5095acece3', '2024-02-03 15:29:25'),
('65bdf965bd9bc', '65bdf965bca3b', '65b509a4e0bae', '65b50cf527c64', '2024-02-03 15:29:25'),
('65bdf971439e0', '65bdf97143994', '65b5074eb165f', '65b507c68a1db', '2024-02-03 15:29:37'),
('65bdf97146206', '65bdf97143994', '65b507f3f1a11', '65b5080a520e8', '2024-02-03 15:29:37'),
('65bdf97148691', '65bdf97143994', '65b5083fdc670', '65b5084943bcb', '2024-02-03 15:29:37'),
('65bdf9714a50a', '65bdf97143994', '65b508fd7bf13', '65b50911b9140', '2024-02-03 15:29:37'),
('65bdf9714d2c4', '65bdf97143994', '65b509460a8dc', '65b5095133140', '2024-02-03 15:29:37'),
('65bdf97150724', '65bdf97143994', '65b509a4e0bae', '65b50ce17f12d', '2024-02-03 15:29:37'),
('65bdf99439bbc', '65bdf99439b74', '65b5074eb165f', '65b507a9af843', '2024-02-03 15:30:12'),
('65bdf99439f72', '65bdf99439b74', '65b507f3f1a11', '65b5080155bb3', '2024-02-03 15:30:12'),
('65bdf9943a211', '65bdf99439b74', '65b5083fdc670', '65b508ca9e9c1', '2024-02-03 15:30:12'),
('65bdf9943a549', '65bdf99439b74', '65b508fd7bf13', '65b5091dc4aac', '2024-02-03 15:30:12'),
('65bdf9943a86a', '65bdf99439b74', '65b509460a8dc', '65b5095133140', '2024-02-03 15:30:12'),
('65bdf9943ab9d', '65bdf99439b74', '65b509a4e0bae', '65b50cf527c64', '2024-02-03 15:30:12'),
('65bdf9a542b81', '65bdf9a542b37', '65b5074eb165f', '65b507c68a1db', '2024-02-03 15:30:29'),
('65bdf9a542f75', '65bdf9a542b37', '65b507f3f1a11', '65b5080155bb3', '2024-02-03 15:30:29'),
('65bdf9a543241', '65bdf9a542b37', '65b5083fdc670', '65b508ca9e9c1', '2024-02-03 15:30:29'),
('65bdf9a5434cb', '65bdf9a542b37', '65b508fd7bf13', '65b5091dc4aac', '2024-02-03 15:30:29'),
('65bdf9a543761', '65bdf9a542b37', '65b509460a8dc', '65b5095acece3', '2024-02-03 15:30:29'),
('65bdf9a5439f6', '65bdf9a542b37', '65b509a4e0bae', '65b50cf527c64', '2024-02-03 15:30:29'),
('65bdf9b44f122', '65bdf9b44f0d8', '65b5074eb165f', '65b507c68a1db', '2024-02-03 15:30:44'),
('65bdf9b44f4ed', '65bdf9b44f0d8', '65b507f3f1a11', '65b5080a520e8', '2024-02-03 15:30:44'),
('65bdf9b44f7d2', '65bdf9b44f0d8', '65b5083fdc670', '65b508ca9e9c1', '2024-02-03 15:30:44'),
('65bdf9b44fac5', '65bdf9b44f0d8', '65b508fd7bf13', '65b5091dc4aac', '2024-02-03 15:30:44'),
('65bdf9b44fdbf', '65bdf9b44f0d8', '65b509460a8dc', '65b5095acece3', '2024-02-03 15:30:44'),
('65bdf9b450102', '65bdf9b44f0d8', '65b509a4e0bae', '65b50cf527c64', '2024-02-03 15:30:44'),
('65bdf9c37cac9', '65bdf9c37ca84', '65b5074eb165f', '65b507c68a1db', '2024-02-03 15:30:59'),
('65bdf9c37ce1a', '65bdf9c37ca84', '65b507f3f1a11', '65b5080a520e8', '2024-02-03 15:30:59'),
('65bdf9c37d0cc', '65bdf9c37ca84', '65b5083fdc670', '65b5084943bcb', '2024-02-03 15:30:59'),
('65bdf9c37d3a9', '65bdf9c37ca84', '65b508fd7bf13', '65b5091dc4aac', '2024-02-03 15:30:59'),
('65bdf9c37d6a0', '65bdf9c37ca84', '65b509460a8dc', '65b5095acece3', '2024-02-03 15:30:59'),
('65bdf9c37d9b1', '65bdf9c37ca84', '65b509a4e0bae', '65b50cf527c64', '2024-02-03 15:30:59'),
('65bdf9d06b221', '65bdf9d06b1d7', '65b5074eb165f', '65b507c68a1db', '2024-02-03 15:31:12'),
('65bdf9d06b618', '65bdf9d06b1d7', '65b507f3f1a11', '65b5080a520e8', '2024-02-03 15:31:12'),
('65bdf9d06b8bb', '65bdf9d06b1d7', '65b5083fdc670', '65b5084943bcb', '2024-02-03 15:31:12'),
('65bdf9d06bb5f', '65bdf9d06b1d7', '65b508fd7bf13', '65b50911b9140', '2024-02-03 15:31:12'),
('65bdf9d06bdf7', '65bdf9d06b1d7', '65b509460a8dc', '65b5095acece3', '2024-02-03 15:31:12'),
('65bdf9d06c091', '65bdf9d06b1d7', '65b509a4e0bae', '65b50ce17f12d', '2024-02-03 15:31:12'),
('65bdf9e000c54', '65bdf9e000c07', '65b5074eb165f', '65b507a9af843', '2024-02-03 15:31:28'),
('65bdf9e001004', '65bdf9e000c07', '65b507f3f1a11', '65b5080155bb3', '2024-02-03 15:31:28'),
('65bdf9e0012cc', '65bdf9e000c07', '65b5083fdc670', '65b5084943bcb', '2024-02-03 15:31:28'),
('65bdf9e00155e', '65bdf9e000c07', '65b508fd7bf13', '65b50911b9140', '2024-02-03 15:31:28'),
('65bdf9e0017d5', '65bdf9e000c07', '65b509460a8dc', '65b5095133140', '2024-02-03 15:31:28'),
('65bdf9e001a86', '65bdf9e000c07', '65b509a4e0bae', '65b50ce17f12d', '2024-02-03 15:31:28'),
('65bdf9eddda86', '65bdf9eddda3d', '65b5074eb165f', '65b507c68a1db', '2024-02-03 15:31:41'),
('65bdf9eddde5e', '65bdf9eddda3d', '65b507f3f1a11', '65b5080155bb3', '2024-02-03 15:31:41'),
('65bdf9edde127', '65bdf9eddda3d', '65b5083fdc670', '65b5084943bcb', '2024-02-03 15:31:41'),
('65bdf9edde40f', '65bdf9eddda3d', '65b508fd7bf13', '65b5091dc4aac', '2024-02-03 15:31:41'),
('65bdf9edde6fc', '65bdf9eddda3d', '65b509460a8dc', '65b5095133140', '2024-02-03 15:31:41'),
('65bdf9edde9ea', '65bdf9eddda3d', '65b509a4e0bae', '65b50ce17f12d', '2024-02-03 15:31:41'),
('65bdfa14d5526', '65bdfa14d54dc', '65b5074eb165f', '65b507a9af843', '2024-02-03 15:32:20'),
('65bdfa14d59ab', '65bdfa14d54dc', '65b507f3f1a11', '65b5080a520e8', '2024-02-03 15:32:20'),
('65bdfa14d5c9b', '65bdfa14d54dc', '65b5083fdc670', '65b508ca9e9c1', '2024-02-03 15:32:20'),
('65bdfa14d5f5a', '65bdfa14d54dc', '65b508fd7bf13', '65b50911b9140', '2024-02-03 15:32:20'),
('65bdfa14d622d', '65bdfa14d54dc', '65b509460a8dc', '65b5095acece3', '2024-02-03 15:32:20'),
('65bdfa14d64ef', '65bdfa14d54dc', '65b509a4e0bae', '65b50cf527c64', '2024-02-03 15:32:20'),
('65bdfa247338b', '65bdfa2473341', '65b5074eb165f', '65b507a9af843', '2024-02-03 15:32:36'),
('65bdfa247388c', '65bdfa2473341', '65b507f3f1a11', '65b5080a520e8', '2024-02-03 15:32:36'),
('65bdfa2473b60', '65bdfa2473341', '65b5083fdc670', '65b508ca9e9c1', '2024-02-03 15:32:36'),
('65bdfa2473e53', '65bdfa2473341', '65b508fd7bf13', '65b5091dc4aac', '2024-02-03 15:32:36'),
('65bdfa247415d', '65bdfa2473341', '65b509460a8dc', '65b5095133140', '2024-02-03 15:32:36'),
('65bdfa247440d', '65bdfa2473341', '65b509a4e0bae', '65b50cf527c64', '2024-02-03 15:32:36'),
('65bdfa41097bd', '65bdfa4109772', '65b5074eb165f', '65b507a9af843', '2024-02-03 15:33:05'),
('65bdfa4109c47', '65bdfa4109772', '65b507f3f1a11', '65b5080a520e8', '2024-02-03 15:33:05'),
('65bdfa4109ef0', '65bdfa4109772', '65b5083fdc670', '65b508ca9e9c1', '2024-02-03 15:33:05'),
('65bdfa410a1fa', '65bdfa4109772', '65b508fd7bf13', '65b50911b9140', '2024-02-03 15:33:05'),
('65bdfa410a4fb', '65bdfa4109772', '65b509460a8dc', '65b5095133140', '2024-02-03 15:33:05'),
('65bdfa410a81b', '65bdfa4109772', '65b509a4e0bae', '65b50cf527c64', '2024-02-03 15:33:05'),
('65bdfec409f78', '65bdfec409f2c', '65b5074eb165f', '65b507c68a1db', '2024-02-03 15:52:20'),
('65bdfec40a72d', '65bdfec409f2c', '65b507f3f1a11', '65b5080155bb3', '2024-02-03 15:52:20'),
('65bdfec40aa29', '65bdfec409f2c', '65b5083fdc670', '65b508ca9e9c1', '2024-02-03 15:52:20'),
('65bdfec40ad1a', '65bdfec409f2c', '65b508fd7bf13', '65b50911b9140', '2024-02-03 15:52:20'),
('65bdfec40b000', '65bdfec409f2c', '65b509460a8dc', '65b5095133140', '2024-02-03 15:52:20'),
('65bdfec40b2dd', '65bdfec409f2c', '65b509a4e0bae', '65b50ce17f12d', '2024-02-03 15:52:20');

-- --------------------------------------------------------

--
-- Struktur dari tabel `himpunan`
--

CREATE TABLE `himpunan` (
  `id_himpunan` varchar(191) NOT NULL,
  `id_variabel` varchar(191) DEFAULT NULL,
  `nama_himpunan` varchar(200) DEFAULT NULL,
  `batas_bawah` double DEFAULT NULL,
  `batas_atas` double DEFAULT NULL,
  `status_himpunan` varchar(50) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data untuk tabel `himpunan`
--

INSERT INTO `himpunan` (`id_himpunan`, `id_variabel`, `nama_himpunan`, `batas_bawah`, `batas_atas`, `status_himpunan`) VALUES
('65b5080a520e8', '65b507f3f1a11', 'Rendah', 50, 100, 'bahu kiri'),
('65b5080155bb3', '65b507f3f1a11', 'Tinggi', 50, 100, 'bahu kanan'),
('65b507c68a1db', '65b5074eb165f', 'Rendah', 50, 100, 'bahu kiri'),
('65b507a9af843', '65b5074eb165f', 'Tinggi', 50, 100, 'bahu kanan'),
('65b5084943bcb', '65b5083fdc670', 'Rendah', 50, 100, 'bahu kiri'),
('65b508ca9e9c1', '65b5083fdc670', 'Tinggi', 50, 100, 'bahu kanan'),
('65b50911b9140', '65b508fd7bf13', 'Rendah', 50, 100, 'bahu kiri'),
('65b5091dc4aac', '65b508fd7bf13', 'Tinggi', 50, 100, 'bahu kanan'),
('65b5095133140', '65b509460a8dc', 'Rendah', 50, 100, 'bahu kiri'),
('65b5095acece3', '65b509460a8dc', 'Tinggi', 50, 100, 'bahu kanan'),
('65b50ce17f12d', '65b509a4e0bae', 'Tidak Layak', 50, 100, 'bahu kiri'),
('65b50cf527c64', '65b509a4e0bae', 'Layak', 50, 100, 'bahu kanan');

-- --------------------------------------------------------

--
-- Struktur dari tabel `login`
--

CREATE TABLE `login` (
  `username` varchar(50) NOT NULL,
  `password` varchar(50) DEFAULT NULL,
  `level` varchar(191) NOT NULL,
  `nama_lengkap` varchar(191) NOT NULL,
  `alamat` varchar(191) NOT NULL,
  `telepon` varchar(191) NOT NULL,
  `jkel` varchar(191) NOT NULL,
  `nik` varchar(191) NOT NULL,
  `email` varchar(191) NOT NULL,
  `ttd` varchar(191) NOT NULL,
  `waktu` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data untuk tabel `login`
--

INSERT INTO `login` (`username`, `password`, `level`, `nama_lengkap`, `alamat`, `telepon`, `jkel`, `nik`, `email`, `ttd`, `waktu`) VALUES
('admin', 'admin', 'admin', 'Administrator', 'Jl. Kuy', '08114114449', 'Laki-laki', '123456789', 'arifsona3@gmail.com', '6449c316d144e.png', '2024-02-03 08:43:41'),
('cikoang', '123', 'pendamping', 'Cikoang', 'cikoang', '082296499165', 'Perempuan', '7306160408830788', 'syarifah.sumarny@gmail.com', '64e9dcc90bbda.jpg', '2024-01-28 00:25:47'),
('punaga', '123', 'pendamping', 'punaga', 'punaga', '082296499161', 'Perempuan', '7306160408830789', 'musyarif040883@gmail.com', '64e9dc8e70e55.jpeg', '2024-01-28 00:26:04');

-- --------------------------------------------------------

--
-- Struktur dari tabel `proposal`
--

CREATE TABLE `proposal` (
  `id_proposal` varchar(191) NOT NULL,
  `nik` varchar(191) DEFAULT NULL,
  `nama_lengkap` varchar(191) DEFAULT NULL,
  `jenis_kelamin` varchar(191) DEFAULT NULL,
  `tempat_lahir` varchar(191) NOT NULL,
  `tgl_lahir` date NOT NULL,
  `alamat` varchar(191) NOT NULL,
  `nama_usaha` varchar(191) NOT NULL,
  `deskripsi_usaha` text NOT NULL,
  `proposal_usaha` varchar(191) NOT NULL,
  `variabel` text NOT NULL,
  `output` varchar(191) NOT NULL,
  `bantuan` varchar(191) NOT NULL,
  `timestamp` datetime NOT NULL DEFAULT current_timestamp(),
  `pendamping` varchar(191) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data untuk tabel `proposal`
--

INSERT INTO `proposal` (`id_proposal`, `nik`, `nama_lengkap`, `jenis_kelamin`, `tempat_lahir`, `tgl_lahir`, `alamat`, `nama_usaha`, `deskripsi_usaha`, `proposal_usaha`, `variabel`, `output`, `bantuan`, `timestamp`, `pendamping`) VALUES
('65b58cca77cdd', '7371032503940001', 'Muh Arifsona', 'Laki-laki', 'Makassar', '1994-03-25', 'Jl. Kijang Lr. 21 No. 29, Kelurahan Maricaiya, Kecamatan Makassar, Kota Makassar, Sulawesi Selatan...', '', '', '', 'Ramah lingkungan(%) : 80 | Menggunakan bahan baku dan atau sumber daya lokal(%) : 35 | Tersedia pasar(%) : 65 | Berpotensi membuka lapangan kerja(%) : 90 | Memiliki potensi berkembang dan berkelanjutan(%) : 85 | ', '60', '', '2024-01-28 06:07:54', 'admin'),
('65b58f6e6c2e5', '7371032503940001', 'Muh Arifsona', 'Laki-laki', 'Makassar', '1994-03-25', 'Jl. Kijang Lr. 21 No. 29, Kelurahan Maricaiya, Kecamatan Makassar, Kota Makassar, Sulawesi Selatan', 'Pempek Doss Mama Rafa', 'Menerima pesanan pempek doss siap saji maupun makanan beku', '65b58f6e6c485.pdf', 'Ramah lingkungan(%) : 89 | Menggunakan bahan baku dan atau sumber daya lokal(%) : 30 | Tersedia pasar(%) : 89 | Berpotensi membuka lapangan kerja(%) : 90 | Memiliki potensi berkembang dan berkelanjutan(%) : 87 | ', '60', '', '2024-01-28 06:19:10', 'admin'),
('65bdfb57b439a', '7371032503940001', 'Muh John', 'Laki-laki', 'Makassar', '1998-02-12', 'Makassar', 'Pisang Ijo Mama Ita', 'Menerima pesanan pisang ijo, siap saji dan frozen', '65bdfb57b457a.pdf', 'Ramah lingkungan(%) : 87 | Menggunakan bahan baku dan atau sumber daya lokal(%) : 90 | Tersedia pasar(%) : 90 | Berpotensi membuka lapangan kerja(%) : 32 | Memiliki potensi berkembang dan berkelanjutan(%) : 34 | ', '80', '', '2024-02-03 15:37:44', 'admin'),
('65bdfc0a11b79', '737101343456346', 'Wira Wahyudi', 'Laki-laki', 'Makassar', '2000-09-08', 'Makassar', 'Wira Computer', 'Jasa Penjualan dan Perbaikan  Spare Part PC & Notebook', '65bdfc0a11fad.pdf', 'Ramah lingkungan(%) : 43 | Menggunakan bahan baku dan atau sumber daya lokal(%) : 32 | Tersedia pasar(%) : 89 | Berpotensi membuka lapangan kerja(%) : 87 | Memiliki potensi berkembang dan berkelanjutan(%) : 90 | ', '83.608695652174', '', '2024-02-03 15:40:42', 'admin'),
('65bdfffabc246', '737102891991201', 'Danu Frimana', 'Laki-laki', 'Jakarta', '2000-09-23', 'Jl. Yuk', 'Pentil Tusuk Ikan Tuna', 'Menyediakan makanan dan jajanan berbahan dasar ikan tuna, menerima pesanan siap saji maupun makanan beku.', '65bdfffabc467.pdf', 'Ramah lingkungan(%) : 89 | Menggunakan bahan baku dan atau sumber daya lokal(%) : 20 | Tersedia pasar(%) : 65 | Berpotensi membuka lapangan kerja(%) : 90 | Memiliki potensi berkembang dan berkelanjutan(%) : 75 | ', '69.051948051948', '', '2024-02-03 15:57:31', 'admin');

-- --------------------------------------------------------

--
-- Struktur dari tabel `variabel`
--

CREATE TABLE `variabel` (
  `id_variabel` varchar(191) NOT NULL,
  `nama_variabel` varchar(200) DEFAULT NULL,
  `satuan_variabel` varchar(50) DEFAULT NULL,
  `status_variabel` varchar(50) DEFAULT NULL,
  `keterangan1` text NOT NULL,
  `keterangan2` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data untuk tabel `variabel`
--

INSERT INTO `variabel` (`id_variabel`, `nama_variabel`, `satuan_variabel`, `status_variabel`, `keterangan1`, `keterangan2`) VALUES
('65b5074eb165f', 'Ramah lingkungan', '%', 'input', '', ''),
('65b507f3f1a11', 'Menggunakan bahan baku dan atau sumber daya lokal', '%', 'input', '', ''),
('65b5083fdc670', 'Tersedia pasar', '%', 'input', '', ''),
('65b508fd7bf13', 'Berpotensi membuka lapangan kerja', '%', 'input', '', ''),
('65b509460a8dc', 'Memiliki potensi berkembang dan berkelanjutan', '%', 'input', '', ''),
('65b509a4e0bae', 'Analisis kelayakan', '%', 'output', '', '');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `aturan`
--
ALTER TABLE `aturan`
  ADD PRIMARY KEY (`id_aturan`);

--
-- Indeks untuk tabel `himpunan`
--
ALTER TABLE `himpunan`
  ADD PRIMARY KEY (`id_himpunan`);

--
-- Indeks untuk tabel `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`username`);

--
-- Indeks untuk tabel `proposal`
--
ALTER TABLE `proposal`
  ADD PRIMARY KEY (`id_proposal`);

--
-- Indeks untuk tabel `variabel`
--
ALTER TABLE `variabel`
  ADD PRIMARY KEY (`id_variabel`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
