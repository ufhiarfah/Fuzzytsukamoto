-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Waktu pembuatan: 27 Jan 2024 pada 19.57
-- Versi server: 10.5.23-MariaDB-cll-lve
-- Versi PHP: 8.1.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `yayasa18_bantuanmodal`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `aturan`
--

CREATE TABLE `aturan` (
  `id_aturan` varchar(191) NOT NULL,
  `nomor` varchar(191) DEFAULT NULL,
  `id_variabel` varchar(191) DEFAULT NULL,
  `id_himpunan` varchar(191) DEFAULT NULL,
  `timestamp` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data untuk tabel `aturan`
--

INSERT INTO `aturan` (`id_aturan`, `nomor`, `id_variabel`, `id_himpunan`, `timestamp`) VALUES
('1', '1', '1', '1', '2024-01-27 19:40:40'),
('10', '3', '2', '4', '2024-01-27 19:40:40'),
('11', '3', '3', '5', '2024-01-27 19:40:40'),
('12', '3', '4', '7', '2024-01-27 19:40:40'),
('13', '4', '1', '1', '2024-01-27 19:40:40'),
('14', '4', '2', '4', '2024-01-27 19:40:40'),
('15', '4', '3', '6', '2024-01-27 19:40:40'),
('16', '4', '4', '7', '2024-01-27 19:40:40'),
('17', '5', '1', '2', '2024-01-27 19:40:40'),
('18', '5', '2', '3', '2024-01-27 19:40:40'),
('19', '5', '3', '5', '2024-01-27 19:40:40'),
('2', '1', '2', '3', '2024-01-27 19:40:40'),
('20', '5', '4', '8', '2024-01-27 19:40:40'),
('21', '6', '1', '2', '2024-01-27 19:40:40'),
('22', '6', '2', '3', '2024-01-27 19:40:40'),
('23', '6', '3', '6', '2024-01-27 19:40:40'),
('24', '6', '4', '8', '2024-01-27 19:40:40'),
('25', '7', '1', '2', '2024-01-27 19:40:40'),
('26', '7', '2', '4', '2024-01-27 19:40:40'),
('27', '7', '3', '5', '2024-01-27 19:40:40'),
('28', '7', '4', '7', '2024-01-27 19:40:40'),
('29', '8', '1', '2', '2024-01-27 19:40:40'),
('3', '1', '3', '5', '2024-01-27 19:40:40'),
('30', '8', '2', '4', '2024-01-27 19:40:40'),
('31', '8', '3', '6', '2024-01-27 19:40:40'),
('32', '8', '4', '7', '2024-01-27 19:40:40'),
('4', '1', '4', '8', '2024-01-27 19:40:40'),
('5', '2', '1', '1', '2024-01-27 19:40:40'),
('6', '2', '2', '3', '2024-01-27 19:40:40'),
('7', '2', '3', '6', '2024-01-27 19:40:40'),
('8', '2', '4', '7', '2024-01-27 19:40:40'),
('9', '3', '1', '1', '2024-01-27 19:40:40');

-- --------------------------------------------------------

--
-- Struktur dari tabel `himpunan`
--

CREATE TABLE `himpunan` (
  `id_himpunan` varchar(191) NOT NULL,
  `id_variabel` varchar(191) DEFAULT NULL,
  `nama_himpunan` varchar(200) DEFAULT NULL,
  `batas_bawah` double DEFAULT NULL,
  `batas_atas` double DEFAULT NULL,
  `status_himpunan` varchar(50) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data untuk tabel `himpunan`
--

INSERT INTO `himpunan` (`id_himpunan`, `id_variabel`, `nama_himpunan`, `batas_bawah`, `batas_atas`, `status_himpunan`) VALUES
('1', '1', 'Sempit', 20, 50, 'bahu kiri'),
('2', '1', 'Luas', 20, 50, 'bahu kanan'),
('3', '2', 'Sedikit', 5, 15, 'bahu kiri'),
('4', '2', 'Banyak', 5, 15, 'bahu kanan'),
('5', '3', 'Hujan / Dingin', 22, 32, 'bahu kiri'),
('6', '3', 'Cerah / Panas', 22, 32, 'bahu kanan'),
('7', '4', 'Turunkan Suhu', 18, 26, 'bahu kiri'),
('8', '4', 'Naikkan Suhu', 18, 26, 'bahu kanan');

-- --------------------------------------------------------

--
-- Struktur dari tabel `login`
--

CREATE TABLE `login` (
  `username` varchar(50) NOT NULL,
  `password` varchar(50) DEFAULT NULL,
  `level` varchar(191) NOT NULL,
  `nama_lengkap` varchar(191) NOT NULL,
  `alamat` varchar(191) NOT NULL,
  `telepon` varchar(191) NOT NULL,
  `jkel` varchar(191) NOT NULL,
  `nik` varchar(191) NOT NULL,
  `email` varchar(191) NOT NULL,
  `ttd` varchar(191) NOT NULL,
  `waktu` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data untuk tabel `login`
--

INSERT INTO `login` (`username`, `password`, `level`, `nama_lengkap`, `alamat`, `telepon`, `jkel`, `nik`, `email`, `ttd`, `waktu`) VALUES
('admin', 'admin', 'admin', 'Rosalia', 'Jl. Kuy', '08114114449', 'Laki-laki', '123456789', 'arifsona3@gmail.com', '6449c316d144e.png', '2023-08-26 12:04:27'),
('cikoang', '12', 'pendamping', 'Cikoang', 'cikoang', '082296499165', 'Perempuan', '7306160408830788', 'syarifah.sumarny@gmail.com', '64e9dcc90bbda.jpg', '2023-08-26 12:06:49'),
('punaga', '1', 'pendamping', 'punaga', 'punaga', '082296499161', 'Perempuan', '7306160408830789', 'musyarif040883@gmail.com', '64e9dc8e70e55.jpeg', '2023-08-26 12:05:50');

-- --------------------------------------------------------

--
-- Struktur dari tabel `penduduk`
--

CREATE TABLE `penduduk` (
  `id_penduduk` varchar(191) NOT NULL,
  `nik` varchar(191) DEFAULT NULL,
  `nama_lengkap` varchar(191) DEFAULT NULL,
  `jenis_kelamin` varchar(191) DEFAULT NULL,
  `tempat_lahir` varchar(191) NOT NULL,
  `tgl_lahir` date NOT NULL,
  `alamat` varchar(191) NOT NULL,
  `variabel` text NOT NULL,
  `output` varchar(191) NOT NULL,
  `bantuan` varchar(191) NOT NULL,
  `timestamp` datetime NOT NULL DEFAULT current_timestamp(),
  `pendamping` varchar(191) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data untuk tabel `penduduk`
--

INSERT INTO `penduduk` (`id_penduduk`, `nik`, `nama_lengkap`, `jenis_kelamin`, `tempat_lahir`, `tgl_lahir`, `alamat`, `variabel`, `output`, `bantuan`, `timestamp`, `pendamping`) VALUES
('6537b83b255ea', '3172015708600004', 'ATIYA', 'Perempuan', 'PEKALONGAN', '1960-08-17', 'CIKOWANG DESA CIKOANG...', 'Kepemilikan Rumah(.) : 2 | Kondisi Papan(.) : 7 | Pengeluaran Pangan(.) : 3 | Sandang(Kali) : 1 | Penghasilan(.) : 2 | ', '19.625', 'PKH,KIP,KIS', '2023-10-24 19:27:39', 'admin'),
('6537c51a41505', '7305024709670001', 'YATI', 'Perempuan', 'TAKALAR', '1962-09-07', 'CIKOWANG DESA CIKOANG...', 'Kepemilikan Rumah(.) : 3 | Kondisi Papan(.) : 5 | Pengeluaran Pangan(.) : 1 | Sandang(Kali) : 1 | Penghasilan(.) : 1 | ', '7.5', 'PKH,KIP', '2023-10-24 20:22:34', 'admin'),
('6537c5e1a2b7f', '7305020507920004', 'MUH. IRFAN', 'Laki-laki', 'JAKARTA', '1992-07-05', 'PUNAGA...', 'Kepemilikan Rumah(.) : 3 | Kondisi Papan(.) : 8 | Pengeluaran Pangan(.) : 4 | Sandang(Kali) : 7 | Penghasilan(.) : 5 | ', '50.496894409938', 'KIP', '2023-10-24 20:25:53', 'admin'),
('653ddf1cec6da', '7326112501850003', 'BASIR', 'Laki-laki', 'PUNAGA', '1985-01-25', 'PUNAGA...', 'Kepemilikan Rumah(.) : 3 | Kondisi Papan(.) : 8 | Pengeluaran Pangan(.) : 3 | Sandang(Kali) : 6 | Penghasilan(.) : 4 | ', '45.253814147018', 'KIP KULIAH', '2023-10-29 11:27:08', 'admin'),
('653ddfb073865', '7305020107620272', 'MANDE', 'Laki-laki', 'TAKALAR', '1962-07-01', 'PUNAGA...', 'Kepemilikan Rumah(.) : 3 | Kondisi Papan(.) : 6 | Pengeluaran Pangan(.) : 2 | Sandang(Kali) : 2 | Penghasilan(.) : 3 | ', '25.551799345692', 'PKH,KIP,KIS', '2023-10-29 11:29:36', 'admin'),
('653de095ab98b', '7305020809890003', 'SUWARDI', 'Laki-laki', 'PUNAGA', '1989-09-08', 'PUNAGA...', 'Kepemilikan Rumah(.) : 2 | Kondisi Papan(.) : 5 | Pengeluaran Pangan(.) : 2 | Sandang(Kali) : 2 | Penghasilan(.) : 2 | ', '18.847080171561', 'PKH,KIP,KIS', '2023-10-29 11:33:25', 'admin'),
('653de10795d6d', '7305022504840001', 'SUDIRMAN', 'Laki-laki', 'LAKATONG', '1984-04-25', 'PUNAGA...', 'Kepemilikan Rumah(.) : 3 | Kondisi Papan(.) : 5 | Pengeluaran Pangan(.) : 2 | Sandang(Kali) : 4 | Penghasilan(.) : 4 | ', '23.592423176167', 'BPNT,KIS', '2023-10-29 11:35:19', 'admin'),
('653de39f2f41d', '7305021507530001', 'ANDI SADDANG', 'Laki-laki', 'JENEPONTO', '1953-07-15', 'PUNAGA...', 'Kepemilikan Rumah(.) : 3 | Kondisi Papan(.) : 7 | Pengeluaran Pangan(.) : 2 | Sandang(Kali) : 3 | Penghasilan(.) : 3 | ', '28.667332667333', 'PKH,KIP,KIS', '2023-10-29 11:46:23', 'admin'),
('653de96f10b5e', '7305021606940005', 'MUH. SUHARDI AIDID', 'Laki-laki', 'CIKOANG', '1994-06-16', 'PUNAGA...', 'Kepemilikan Rumah(.) : 2 | Kondisi Papan(.) : 5 | Pengeluaran Pangan(.) : 4 | Sandang(Kali) : 4 | Penghasilan(.) : 4 | ', '20.312859057832', 'BPNT,PKH,KIS', '2023-10-29 12:11:11', 'admin'),
('653de9c29e04d', '7305024802650001', 'INTAN', 'Perempuan', 'MALELAYA', '1965-02-08', 'PUNAGA...', 'Kepemilikan Rumah(.) : 3 | Kondisi Papan(.) : 6 | Pengeluaran Pangan(.) : 2 | Sandang(Kali) : 2 | Penghasilan(.) : 3 | ', '25.551799345692', 'PKH,KIP,KIS', '2023-10-29 12:12:34', 'admin'),
('653dea134f70d', '7371041203910001', 'SAHABUDDIN', 'Laki-laki', 'LAKATONG PULAU', '1991-03-12', 'PUNAGA...', 'Kepemilikan Rumah(.) : 3 | Kondisi Papan(.) : 5 | Pengeluaran Pangan(.) : 2 | Sandang(Kali) : 2 | Penghasilan(.) : 3 | ', '22.310462359218', 'PKH,KIS', '2023-10-29 12:13:55', 'admin'),
('653dea81891c1', '7305024107760258', 'RAHMAWATI', 'Perempuan', 'PUNAGA', '1976-07-01', 'PUNAGA...', 'Kepemilikan Rumah(.) : 3 | Kondisi Papan(.) : 5 | Pengeluaran Pangan(.) : 1 | Sandang(Kali) : 1 | Penghasilan(.) : 1 | ', '7.5', 'PKH,KIP', '2023-10-29 12:15:45', 'admin'),
('653ded6b21faa', '7305020606730001', 'GADING', 'Laki-laki', 'PARASANGANG BERU', '1973-06-04', 'BILA-BILAYA, CIKOANG...', 'Kepemilikan Rumah(.) : 3 | Kondisi Papan(.) : 6 | Pengeluaran Pangan(.) : 2 | Sandang(Kali) : 2 | Penghasilan(.) : 2 | ', '23.105006105006', 'PKH,KIP,KIS', '2023-10-29 12:28:11', 'admin'),
('653dedd088f0f', '7305020811680001', 'KAMARUDDIN', 'Laki-laki', 'JONGGOWA', '1968-11-08', 'CIKOWANG DESA CIKOANG...', 'Kepemilikan Rumah(.) : 3 | Kondisi Papan(.) : 6 | Pengeluaran Pangan(.) : 1 | Sandang(Kali) : 01 | Penghasilan(.) : 1 | ', '15', 'PKH,KIP', '2023-10-29 12:29:52', 'admin'),
('653dee4fe3a7b', '7305024107780246', 'SUSILAWATI', 'Perempuan', 'TAKALAR', '1978-07-01', 'CIKOWANG DESA CIKOANG...', 'Kepemilikan Rumah(.) : 3 | Kondisi Papan(.) : 6 | Pengeluaran Pangan(.) : 1 | Sandang(Kali) : 1 | Penghasilan(.) : 1 | ', '15', 'PKH,KIP', '2023-10-29 12:31:59', 'admin'),
('653df00c975b9', '7305021002690001', 'ARIFIN TUMBA', 'Laki-laki', 'CIKOANG', '1969-02-10', 'CIKOWANG DESA CIKOANG...', 'Kepemilikan Rumah(.) : 3 | Kondisi Papan(.) : 06 | Pengeluaran Pangan(.) : 2 | Sandang(Kali) : 1 | Penghasilan(.) : 2 | ', '20.636363636364', 'PKH,KIP', '2023-10-29 12:39:24', 'admin'),
('653df07c13f9c', '7305022502920002', 'SAYYED GUDR', 'Laki-laki', 'CIKOANG', '1992-02-25', 'JONGGOA DESA CIKOANG...', 'Kepemilikan Rumah(.) : 2 | Kondisi Papan(.) : 5 | Pengeluaran Pangan(.) : 2 | Sandang(Kali) : 2 | Penghasilan(.) : 3 | ', '18.720161782662', 'PKH,KIS', '2023-10-29 12:41:16', 'admin'),
('653df0d36d0e7', '7305024107550194', 'SILLONG DG BAU', 'Perempuan', 'CIKOANG', '1955-07-01', 'CIKOWANG DESA CIKOANG...', 'Kepemilikan Rumah(.) : 2 | Kondisi Papan(.) : 5 | Pengeluaran Pangan(.) : 1 | Sandang(Kali) : 1 | Penghasilan(.) : 1 | ', '9.1666666666667', 'PKH,KIP', '2023-10-29 12:42:43', 'admin'),
('653df126caf6c', '7305021108930003', 'KAHARUDDIN', 'Laki-laki', 'CIKOANG', '1993-08-11', 'JONGGOA DESA CIKOANG...', 'Kepemilikan Rumah(.) : 3 | Kondisi Papan(.) : 5 | Pengeluaran Pangan(.) : 3 | Sandang(Kali) : 3 | Penghasilan(.) : 3 | ', '24.1171552436', 'PKH,KIS', '2023-10-29 12:44:06', 'admin'),
('653df1d59b17e', '7305021210750002', 'YAHA', 'Laki-laki', 'CIKOANG', '1975-10-12', 'BILA-BILAYA, CIKOANG...', 'Kepemilikan Rumah(.) : 3 | Kondisi Papan(.) : 5 | Pengeluaran Pangan(.) : 2 | Sandang(Kali) : 1 | Penghasilan(.) : 3 | ', '19.554347826087', 'PKH,KIP,KIS', '2023-10-29 12:47:01', 'admin'),
('653df246935f1', '7305020405900002', 'RUSTAM', 'Laki-laki', 'LAIKANG', '1990-05-04', 'BILA-BILAYA, CIKOANG...', 'Kepemilikan Rumah(.) : 3 | Kondisi Papan(.) : 6 | Pengeluaran Pangan(.) : 4 | Sandang(Kali) : 3 | Penghasilan(.) : 4 | ', '27.895190236899', 'PKH,KIS', '2023-10-29 12:48:54', 'admin'),
('653df2bcdb56b', '7305020504950002', 'BASRI', 'Laki-laki', 'BONTO-BONTO', '1995-04-05', 'BILA-BILAYA, CIKOANG...', 'Kepemilikan Rumah(.) : 3 | Kondisi Papan(.) : 7 | Pengeluaran Pangan(.) : 3 | Sandang(Kali) : 3 | Penghasilan(.) : 4 | ', '32.263005780347', 'PKH,KIS', '2023-10-29 12:50:52', 'admin'),
('653df8041d837', '7305010107910199', 'MADI', 'Laki-laki', 'TOMPO TANA', '1991-07-01', 'CIKOWANG DESA CIKOANG...', 'Kepemilikan Rumah(.) : 2 | Kondisi Papan(.) : 05 | Pengeluaran Pangan(.) : 02 | Sandang(Kali) : 1 | Penghasilan(.) : 2 | ', '16.653846153846', 'PKH,KIP,KIS', '2023-10-29 13:13:24', 'admin'),
('654e1eed86b2e', '7306160408830009', 'YAKIN', 'Laki-laki', 'TAKALAR', '2001-03-21', 'BILA-BILAYA DESA CIKOANG...', 'Kepemilikan Rumah(.) : 3 | Kondisi Papan(.) : 8 | Pengeluaran Pangan(.) : 6 | Sandang(Kali) : 8 | Penghasilan(.) : 6 | ', '100', 'KIP KULIAH', '2023-11-10 19:15:41', 'admin'),
('654f6ef5bce30', '7306160408830001', 'yes', 'Perempuan', 'TAKALAR', '2000-12-22', 'punaga', 'Kepemilikan Rumah(.) : 2 | Kondisi Papan(.) : 5 | Pengeluaran Pangan(.) : 2 | Sandang(Kali) : 2 | Penghasilan(.) : 3 | ', '18.720161782662', '', '2023-11-11 19:09:25', 'punaga'),
('655430b83c659', '7306160408830555', 'WATI', 'Perempuan', 'CIKOANG', '1980-03-22', 'CIKOWANG DESA CIKOANG...', 'Kepemilikan Rumah(.) : 3 | Kondisi Papan(.) : 4 | Pengeluaran Pangan(.) : 3 | Sandang(Kali) : 2 | Penghasilan(.) : 03 | ', '27.895186335404', 'BPNT,PKH,KIS', '2023-11-15 09:45:12', 'admin'),
('6554461624ec7', '7371103005850017', 'DANANG', 'Laki-laki', 'CIKOANG', '1985-05-30', 'CIKOWANG DESA CIKOANG...', 'Kepemilikan Rumah(.) : 3 | Kondisi Papan(.) : 02 | Pengeluaran Pangan(.) : 4 | Sandang(Kali) : 5 | Penghasilan(.) : 4 | Tanggungan(.) : 0 | ', '25.257653061224', 'BPNT,KIS', '2023-11-15 11:16:22', 'admin');

-- --------------------------------------------------------

--
-- Struktur dari tabel `variabel`
--

CREATE TABLE `variabel` (
  `id_variabel` varchar(191) NOT NULL,
  `nama_variabel` varchar(200) DEFAULT NULL,
  `satuan_variabel` varchar(50) DEFAULT NULL,
  `status_variabel` varchar(50) DEFAULT NULL,
  `keterangan1` text NOT NULL,
  `keterangan2` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data untuk tabel `variabel`
--

INSERT INTO `variabel` (`id_variabel`, `nama_variabel`, `satuan_variabel`, `status_variabel`, `keterangan1`, `keterangan2`) VALUES
('4', 'Suhu AC', 'celcius', 'output', '', ''),
('2', 'Jumlah Orang', 'org', 'input', '', ''),
('3', 'Suhu Cuaca Luar', 'celcius', 'input', '', ''),
('1', 'Besar Ruangan', 'm2', 'input', '', '');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `aturan`
--
ALTER TABLE `aturan`
  ADD PRIMARY KEY (`id_aturan`);

--
-- Indeks untuk tabel `himpunan`
--
ALTER TABLE `himpunan`
  ADD PRIMARY KEY (`id_himpunan`);

--
-- Indeks untuk tabel `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`username`);

--
-- Indeks untuk tabel `penduduk`
--
ALTER TABLE `penduduk`
  ADD PRIMARY KEY (`id_penduduk`);

--
-- Indeks untuk tabel `variabel`
--
ALTER TABLE `variabel`
  ADD PRIMARY KEY (`id_variabel`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
